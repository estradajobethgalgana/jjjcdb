
CREATE DATABASE IF NOT EXISTS moviegame_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE moviegame_db;

CREATE TABLE IF NOT EXISTS users (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(30)  NOT NULL UNIQUE,
    first_name      VARCHAR(50)  NOT NULL,
    last_name       VARCHAR(50)  NOT NULL,
    date_of_birth   DATE         NOT NULL,
    email           VARCHAR(120) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    avatar          VARCHAR(255) DEFAULT NULL,
    bio             VARCHAR(500) DEFAULT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS genres (
    id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name    VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS movies (
    id                      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title                   VARCHAR(200) NOT NULL,
    description             TEXT,
    release_year            SMALLINT UNSIGNED,
    release_date            DATE DEFAULT NULL,
    poster_url              VARCHAR(500),
    backdrop_url            VARCHAR(500),
    external_rating         DECIMAL(2,1) DEFAULT 0.0,
    external_rating_source  VARCHAR(50)  DEFAULT 'TMDB',
    external_rating_count   INT UNSIGNED DEFAULT 0,
    created_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_movie_title_year (title, release_year),
    INDEX idx_movie_rating (external_rating),
    INDEX idx_movie_release (release_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS games (
    id                      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title                   VARCHAR(200) NOT NULL,
    description             TEXT,
    release_year            SMALLINT UNSIGNED,
    release_date            DATE DEFAULT NULL,
    cover_url               VARCHAR(500),
    backdrop_url            VARCHAR(500),
    external_rating         DECIMAL(2,1) DEFAULT 0.0,
    external_rating_source  VARCHAR(50)  DEFAULT 'IGDB',
    external_rating_count   INT UNSIGNED DEFAULT 0,
    created_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_game_title_year (title, release_year),
    INDEX idx_game_rating (external_rating),
    INDEX idx_game_release (release_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS movie_genres (
    movie_id  INT UNSIGNED NOT NULL,
    genre_id  INT UNSIGNED NOT NULL,
    PRIMARY KEY (movie_id, genre_id),
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
    FOREIGN KEY (genre_id) REFERENCES genres(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS game_genres (
    game_id   INT UNSIGNED NOT NULL,
    genre_id  INT UNSIGNED NOT NULL,
    PRIMARY KEY (game_id, genre_id),
    FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE,
    FOREIGN KEY (genre_id) REFERENCES genres(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS collections (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    item_type   ENUM('movie','game') NOT NULL,
    item_id     INT UNSIGNED NOT NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_collection_item (user_id, item_type, item_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_collection_user (user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS reviews (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL,
    item_type    ENUM('movie','game') NOT NULL,
    item_id      INT UNSIGNED NOT NULL,
    rating       DECIMAL(2,1) NOT NULL,
    review_text  TEXT NOT NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_review_item (user_id, item_type, item_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_review_item (item_type, item_id)
) ENGINE=InnoDB;
