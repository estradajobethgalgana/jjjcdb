<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (php_sapi_name() !== 'cli' && !isset($_GET['confirm'])) {
    die('To seed the database from a browser, visit this file with ?confirm=1 — or run `php database/seed.php` from the command line.');
}

$db = Database::getConnection();

echo "== JJJC.Collect database seed ==\n";

$movieGenreNames = ['Action','Adventure','Animation','Comedy','Crime','Drama','Fantasy','Horror','Romance','Science Fiction','Thriller','Mystery'];
$gameGenreNames  = ['Action','Adventure','RPG','Strategy','Simulation','Sports','Racing','Horror','Fighting','Shooter','Platformer','Puzzle'];
$allGenreNames = array_values(array_unique(array_merge($movieGenreNames, $gameGenreNames)));

$insertGenre = $db->prepare('INSERT IGNORE INTO genres (name) VALUES (?)');
foreach ($allGenreNames as $name) {
    $insertGenre->execute([$name]);
}
$genreIdMap = [];
foreach ($db->query('SELECT id, name FROM genres')->fetchAll() as $row) {
    $genreIdMap[$row['name']] = (int)$row['id'];
}
echo 'Genres ready: ' . count($genreIdMap) . "\n";

function synth_rating(string $seed, float $min = 2.8, float $max = 4.9): float
{
    $hash = crc32($seed);
    $range = ($max - $min) * 10;
    $steps = $hash % ((int)$range + 1);
    return round($min + ($steps / 10), 1);
}
function synth_count(string $seed, int $min = 800, int $max = 45000): int
{
    $hash = crc32($seed . '-count');
    return $min + ($hash % ($max - $min));
}
function synth_date(int $year, string $seed): string
{
    $hash = crc32($seed . '-date');
    $month = 1 + ($hash % 12);
    $day = 1 + (($hash >> 4) % 28);
    return sprintf('%04d-%02d-%02d', $year, $month, $day);
}

function slugify(string $title): string
{
    $slug = strtolower($title);
    $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
    return trim($slug, '-');
}

function local_image(string $webDir, string $title): ?string
{
    $slug = slugify($title);
    $exts = ['jpg', 'jpeg', 'png', 'webp'];
    foreach ($exts as $ext) {
        $diskPath = __DIR__ . '/../' . $webDir . '/' . $slug . '.' . $ext;
        if (is_file($diskPath)) {
            return $webDir . '/' . $slug . '.' . $ext;
        }
    }
    return null;
}

$movies = [
  ['The Dark Knight', 2008, ['Action','Crime','Drama','Thriller'], 'A vigilante crime-fighter faces a chaos-driven criminal mastermind who wants to prove chaos always wins.'],
  ['Mad Max: Fury Road', 2015, ['Action','Adventure','Science Fiction'], 'In a scorched wasteland, a rebel driver and a fierce warrior lead a desperate escape from a tyrant.'],
  ['Inception', 2010, ['Science Fiction','Action','Adventure','Thriller'], 'A thief who steals secrets through dream-sharing technology is offered a chance to have his past erased.'],
  ['Spider-Man: Into the Spider-Verse', 2018, ['Animation','Action','Adventure','Science Fiction'], 'A teenager discovers he shares his universe with other versions of a certain web-slinging hero.'],
  ['Knives Out', 2019, ['Comedy','Crime','Mystery','Thriller'], "A detective investigates the suspicious death of a wealthy crime novelist surrounded by his scheming family."],
  ['The Grand Budapest Hotel', 2014, ['Comedy','Adventure','Crime'], 'A legendary concierge and his protégé become entangled in a theft and murder investigation at a famed hotel.'],
  ['Parasite', 2019, ['Thriller','Drama','Comedy'], 'A poor family schemes to become employed by a wealthy household with unforeseen consequences.'],
  ['Se7en', 1995, ['Crime','Mystery','Thriller','Drama'], 'Two detectives hunt a serial killer who uses the seven deadly sins as his motive.'],
  ['Get Out', 2017, ['Horror','Mystery','Thriller'], "A young man uncovers a disturbing secret when he meets his girlfriend's seemingly welcoming family."],
  ['The Shining', 1980, ['Horror','Drama','Thriller'], "A family's stay as winter caretakers of an isolated hotel turns increasingly sinister."],
  ["Pan's Labyrinth", 2006, ['Fantasy','Drama','Horror'], 'A young girl escapes a brutal postwar reality by entering a dark fantastical labyrinth.'],
  ['The Princess Bride', 1987, ['Fantasy','Adventure','Comedy','Romance'], 'A farmhand embarks on a quest to rescue his true love from an unwanted engagement.'],
  ['La La Land', 2016, ['Romance','Drama','Comedy'], 'An aspiring actress and a dedicated jazz musician pursue their dreams while falling for each other in Los Angeles.'],
  ['Eternal Sunshine of the Spotless Mind', 2004, ['Romance','Drama','Science Fiction'], 'A heartbroken man undergoes a procedure to erase memories of his former relationship.'],
  ['The Shape of Water', 2017, ['Fantasy','Drama','Romance'], 'A mute cleaning woman forms a unique bond with a mysterious amphibious creature held in a secret facility.'],
  ['Up', 2009, ['Adventure','Animation','Comedy','Drama'], 'An elderly widower ties balloons to his house and sets off on an unlikely journey to South America.'],
  ['Coco', 2017, ['Animation','Adventure','Comedy','Drama'], "A boy is transported to the Land of the Dead and uncovers his family's true history."],
  ['Zootopia', 2016, ['Animation','Adventure','Comedy','Mystery'], 'A rookie rabbit officer teams with a con-artist fox to crack a mysterious case in a city of animals.'],
  ['Spirited Away', 2001, ['Animation','Adventure','Fantasy'], 'A young girl must work in a bathhouse for spirits to save her transformed parents.'],
  ['WALL-E', 2008, ['Animation','Adventure','Science Fiction','Comedy'], 'A lonely trash-collecting robot on a ruined Earth falls for a sleek scanning probe from space.'],
  ['The Lord of the Rings: The Fellowship of the Ring', 2001, ['Adventure','Fantasy','Drama'], 'A hobbit and his companions set out to destroy a powerful ring before it falls into darkness.'],
  ['Gladiator', 2000, ['Action','Adventure','Drama'], 'A betrayed Roman general fights his way from slavery to the arena to seek vengeance.'],
  ['The Godfather', 1972, ['Crime','Drama'], 'The aging patriarch of a crime family transfers control to his reluctant son.'],
  ['Pulp Fiction', 1994, ['Crime','Thriller','Drama'], "The lives of two hitmen, a boxer, and a gangster's wife intertwine in four tales of violence."],
  ['The Departed', 2006, ['Crime','Drama','Thriller'], 'An undercover cop and a mob informant each try to root out the other inside a Boston gang.'],
  ['American History X', 1998, ['Crime','Drama'], 'A reformed neo-Nazi tries to prevent his younger brother from following the same violent path.'],
  ['Interstellar', 2014, ['Adventure','Science Fiction','Drama'], 'A team of explorers travels through a wormhole in search of a new home for humanity.'],
  ['Arrival', 2016, ['Science Fiction','Drama','Mystery'], 'A linguist is recruited to communicate with mysterious extraterrestrial visitors before global tensions escalate.'],
  ['Blade Runner 2049', 2017, ['Science Fiction','Drama','Thriller'], 'A young blade runner uncovers a secret that could plunge society into chaos.'],
  ['Gone Girl', 2014, ['Thriller','Mystery','Drama'], "A man becomes the prime suspect in the media frenzy surrounding his wife's sudden disappearance."],
  ['Shutter Island', 2010, ['Thriller','Mystery','Drama'], 'A U.S. Marshal investigates the disappearance of a patient from an isolated psychiatric hospital.'],
  ['Murder on the Orient Express', 2017, ['Mystery','Crime','Drama'], 'A famed detective investigates a murder aboard a luxury train stranded in the snow.'],
  ['Rear Window', 1954, ['Mystery','Thriller'], 'A wheelchair-bound photographer becomes convinced a neighbor has committed murder.'],
  ['Titanic', 1997, ['Romance','Drama'], 'A penniless artist and a young aristocrat fall in love aboard the ill-fated ocean liner.'],
  ['Notting Hill', 1999, ['Romance','Comedy','Drama'], "A humble London bookseller's life changes when he falls for a famous American actress."],
  ['The Notebook', 2004, ['Romance','Drama'], 'An elderly man reads a love story to a woman with memory loss in a nursing home.'],
  ['Halloween', 1978, ['Horror','Thriller'], 'A masked killer returns to his hometown to stalk a group of teenage babysitters.'],
  ['Hereditary', 2018, ['Horror','Drama','Mystery'], "A family unravels dark secrets following the death of their secretive grandmother."],
  ['A Quiet Place', 2018, ['Horror','Thriller','Science Fiction','Drama'], 'A family must live in silence to avoid deadly creatures that hunt by sound.'],
];

$games = [
  ["Marvel's Spider-Man", 2018, ['Action','Adventure'], 'A young hero balances his personal life with the responsibilities of protecting his city.'],
  ['Elden Ring', 2022, ['RPG','Action','Adventure'], 'A tarnished explorer traverses a shattered realm to restore a broken ring of power.'],
  ['The Legend of Zelda: Breath of the Wild', 2017, ['Action','Adventure','RPG'], 'A hero awakens after a century of slumber to reclaim a kingdom overrun by ancient calamity.'],
  ['God of War (2018)', 2018, ['Action','Adventure'], 'A vengeful warrior and his young son journey through Norse realms haunted by his past.'],
  ['Hades', 2020, ['Action','RPG'], 'The son of the underworld god repeatedly battles his way toward the surface world.'],
  ['Sekiro: Shadows Die Twice', 2019, ['Action','RPG','Adventure'], 'A disgraced shinobi seeks revenge and redemption in a brutal, sword-fighting feudal Japan.'],
  ['Destiny 2', 2017, ['Shooter','RPG','Action'], "Guardians defend humanity's last city while exploring the solar system for ancient power."],
  ['Borderlands 3', 2019, ['Shooter','RPG','Action'], 'Vault Hunters chase legendary loot across a chaotic galaxy of bandits and cults.'],
  ['Civilization VI', 2016, ['Strategy'], 'Players guide a civilization from the Stone Age to the Information Age through diplomacy, war, and culture.'],
  ['XCOM 2', 2016, ['Strategy'], 'A resistance force wages guerrilla warfare against an alien occupation of Earth.'],
  ['Fire Emblem: Three Houses', 2019, ['Strategy','RPG'], 'A mercenary-turned-professor guides students from one of three rival houses through a continent-spanning war.'],
  ['Stellaris', 2016, ['Strategy','Simulation'], 'Players guide a spacefaring civilization as it explores, colonizes, and negotiates a vast galaxy.'],
  ['Into the Breach', 2018, ['Strategy','Puzzle'], 'Pilots travel back in time to command mechs defending cities from enormous subterranean monsters.'],
  ['The Sims 4', 2014, ['Simulation'], 'Players create and control virtual people, guiding their relationships, careers, and daily lives.'],
  ['Stardew Valley', 2016, ['Simulation','RPG'], 'A burnt-out office worker inherits a rundown farm and rebuilds a life in a charming rural town.'],
  ['Cities: Skylines', 2015, ['Simulation','Strategy'], "Players design and manage a growing city's infrastructure, economy, and services."],
  ['Animal Crossing: New Horizons', 2020, ['Simulation'], 'Players build a community from scratch on a deserted island alongside a cast of animal neighbors.'],
  ['FIFA 23', 2022, ['Sports'], 'Players compete in realistic club and international football matches with licensed teams and stadiums.'],
  ['NBA 2K23', 2022, ['Sports'], 'Players build a basketball career or manage a franchise in realistic on-court simulation.'],
  ['Rocket League', 2015, ['Sports','Racing'], 'Players control rocket-powered cars in a high-speed sport that combines soccer with vehicular acrobatics.'],
  ['Mario Kart 8 Deluxe', 2017, ['Racing'], 'Familiar characters race go-karts across whimsical tracks armed with chaotic power-up items.'],
  ['Forza Horizon 5', 2021, ['Racing'], "Players race across a vibrant open-world recreation of Mexico's diverse landscapes."],
  ['Gran Turismo 7', 2022, ['Racing','Simulation'], 'Players collect, tune, and race an extensive roster of realistic cars across global tracks.'],
  ['Resident Evil 2', 2019, ['Horror','Shooter','Action'], 'Survivors navigate a zombie-infested police station while being hunted by a relentless bio-weapon.'],
  ['Silent Hill 2', 2001, ['Horror','Adventure'], 'A grieving widower searches a fog-shrouded town for the wife who supposedly died years earlier.'],
  ['Outlast', 2013, ['Horror','Adventure'], 'A journalist investigating an asylum must flee horrors unleashed by a sinister experiment.'],
  ['Dead Space', 2008, ['Horror','Shooter','Action'], 'An engineer battles mutated creatures aboard a derelict mining ship adrift in deep space.'],
  ['Phasmophobia', 2020, ['Horror','Simulation'], 'Players investigate haunted locations as ghost hunters gathering evidence of paranormal activity.'],
  ['Street Fighter 6', 2023, ['Fighting'], 'Fighters from around the world compete using a mix of classic and modernized combat techniques.'],
  ['Mortal Kombat 11', 2019, ['Fighting'], 'Warriors from rival realms battle across time to prevent history from being rewritten.'],
  ['Super Smash Bros. Ultimate', 2018, ['Fighting','Platformer','Action'], "Characters from across gaming history battle it out on stages inspired by their home franchises."],
  ['Tekken 7', 2015, ['Fighting'], 'A sprawling martial arts tournament fuels a generations-long family feud for control of a global empire.'],
  ['Call of Duty: Modern Warfare II', 2022, ['Shooter','Action'], 'An elite task force races against an international arms dealer threatening global stability.'],
  ['Halo Infinite', 2021, ['Shooter','Action','Adventure'], 'A lone super-soldier must rally scattered allies to stop a fractured alien threat.'],
  ['Apex Legends', 2019, ['Shooter','Action'], 'Squads of legendary characters battle to be the last team standing on a shrinking battlefield.'],
  ['Super Mario Odyssey', 2017, ['Platformer','Adventure','Action'], 'A plumber travels across whimsical kingdoms using a sentient cap to rescue a kidnapped princess.'],
  ['Hollow Knight', 2017, ['Platformer','Adventure','Action','RPG'], 'A small knight explores a vast, ruined insect kingdom hiding ancient secrets and dangers.'],
  ['Celeste', 2018, ['Platformer','Puzzle'], 'A young woman climbs a mysterious mountain while confronting her own inner struggles.'],
  ['Portal 2', 2011, ['Puzzle','Adventure'], 'A test subject solves increasingly complex spatial puzzles using a gun that creates linked portals.'],
  ['Baba Is You', 2019, ['Puzzle'], 'Players rearrange the rules of the game itself, written as blocks, to solve each puzzle.'],
  ['Tetris Effect', 2018, ['Puzzle'], 'Players clear falling lines of blocks across dazzling, music-synchronized backdrops.'],
  ['Madden NFL 23', 2022, ['Sports'], 'Players call plays and manage rosters in a detailed simulation of American football.'],
  ["Tony Hawk's Pro Skater 2", 2000, ['Sports'], 'Players chain together tricks and combos across iconic skateboarding levels.'],
  ['Need for Speed Heat', 2019, ['Racing','Action'], 'Street racers battle rival crews and a corrupt police task force in a sun-soaked city.'],
  ['King of Fighters XV', 2022, ['Fighting'], 'Teams of three fighters compete in a long-running tournament steeped in franchise rivalries.'],
  ['Donkey Kong Country: Tropical Freeze', 2014, ['Platformer','Adventure'], 'A gorilla and his allies fight to reclaim their island from a horde of icy invaders.'],
];

$insertMovie = $db->prepare("
    INSERT IGNORE INTO movies
      (title, description, release_year, release_date, poster_url, backdrop_url, external_rating, external_rating_source, external_rating_count)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'TMDB', ?)
");
$findMovie = $db->prepare('SELECT id FROM movies WHERE title = ? AND release_year = ?');
$linkMovieGenre = $db->prepare('INSERT IGNORE INTO movie_genres (movie_id, genre_id) VALUES (?, ?)');
$updateMovieImages = $db->prepare("
    UPDATE movies SET poster_url = ?, backdrop_url = ?, external_rating_source = 'TMDB'
    WHERE title = ? AND release_year = ?
");

$movieCount = 0;
$localHits = 0;
foreach ($movies as [$title, $year, $genres, $desc]) {
    $rating = synth_rating($title);
    $count  = synth_count($title);
    $date   = synth_date($year, $title);

    $localPoster = local_image('assets/img/posters', $title);
    if ($localPoster) {
        $localHits++;
        $realPoster = $localPoster;
        $realBackdrop = $localPoster;
    } else {
        $realPoster = null;
        $realBackdrop = null;
    }
    $poster = $realPoster ?: placeholder_image('movie-' . $title, 400, 600);
    $backdrop = $realBackdrop ?: placeholder_image('movie-' . $title . '-bg', 1280, 500);

    $insertMovie->execute([$title, $desc, $year, $date, $poster, $backdrop, $rating, $count]);
    $findMovie->execute([$title, $year]);
    $movieId = (int)$findMovie->fetchColumn();

    if ($realPoster) {
        $updateMovieImages->execute([$poster, $backdrop, $title, $year]);
    }

    foreach ($genres as $g) {
        if (isset($genreIdMap[$g])) {
            $linkMovieGenre->execute([$movieId, $genreIdMap[$g]]);
        }
    }
    $movieCount++;
}
echo "Movies processed: {$movieCount}\n";
echo "  \u2192 local images used for {$localHits}/{$movieCount} movies (assets/img/posters/)\n";
echo "  \u2192 the rest are using placeholder images \u2014 drop a matching file into assets/img/posters/ any time\n";

$insertGame = $db->prepare("
    INSERT IGNORE INTO games
      (title, description, release_year, release_date, cover_url, backdrop_url, external_rating, external_rating_source, external_rating_count)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'RAWG', ?)
");
$findGame = $db->prepare('SELECT id FROM games WHERE title = ? AND release_year = ?');
$linkGameGenre = $db->prepare('INSERT IGNORE INTO game_genres (game_id, genre_id) VALUES (?, ?)');
$updateGameImages = $db->prepare("
    UPDATE games SET cover_url = ?, backdrop_url = ?, external_rating_source = 'RAWG'
    WHERE title = ? AND release_year = ?
");

$gameCount = 0;
$localGameHits = 0;
foreach ($games as [$title, $year, $genres, $desc]) {
    $rating = synth_rating($title . '-game');
    $count  = synth_count($title . '-game');
    $date   = synth_date($year, $title . '-game');

    $localCover = local_image('assets/img/covers', $title);
    if ($localCover) {
        $localGameHits++;
        $realImage = $localCover;
    } else {
        $realImage = null;
    }
    $cover  = $realImage ?: placeholder_image('game-' . $title, 400, 600);
    $backdrop = $realImage ?: placeholder_image('game-' . $title . '-bg', 1280, 500);

    $insertGame->execute([$title, $desc, $year, $date, $cover, $backdrop, $rating, $count]);
    $findGame->execute([$title, $year]);
    $gameId = (int)$findGame->fetchColumn();

    if ($realImage) {
        $updateGameImages->execute([$cover, $backdrop, $title, $year]);
    }

    foreach ($genres as $g) {
        if (isset($genreIdMap[$g])) {
            $linkGameGenre->execute([$gameId, $genreIdMap[$g]]);
        }
    }
    $gameCount++;
}
echo "Games processed: {$gameCount}\n";
echo "  \u2192 local images used for {$localGameHits}/{$gameCount} games (assets/img/covers/)\n";
echo "  \u2192 the rest are using placeholder images \u2014 drop a matching file into assets/img/covers/ any time\n";

echo "\n== Genre verification ==\n";
echo "-- Movies --\n";
foreach ($movieGenreNames as $g) {
    $stmt = $db->prepare("
        SELECT COUNT(DISTINCT m.id) c FROM movies m
        JOIN movie_genres mg ON mg.movie_id = m.id
        JOIN genres ge ON ge.id = mg.genre_id
        WHERE ge.name = ?
    ");
    $stmt->execute([$g]);
    $c = (int)$stmt->fetchColumn();
    echo str_pad($g, 20) . $c . ($c >= 5 ? ' OK' : ' *** NEEDS MORE DATA ***') . "\n";
}
echo "-- Games --\n";
foreach ($gameGenreNames as $g) {
    $stmt = $db->prepare("
        SELECT COUNT(DISTINCT g2.id) c FROM games g2
        JOIN game_genres gg ON gg.game_id = g2.id
        JOIN genres ge ON ge.id = gg.genre_id
        WHERE ge.name = ?
    ");
    $stmt->execute([$g]);
    $c = (int)$stmt->fetchColumn();
    echo str_pad($g, 20) . $c . ($c >= 5 ? ' OK' : ' *** NEEDS MORE DATA ***') . "\n";
}

echo "\nSeed complete. Movies: {$movieCount}, Games: {$gameCount}\n";
