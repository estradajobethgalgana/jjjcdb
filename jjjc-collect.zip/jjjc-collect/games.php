<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login();

$filterType = 'game';
$selectedGenres = isset($_GET['genre']) && is_array($_GET['genre']) ? array_map('strval', $_GET['genre']) : [];
$minRating = isset($_GET['min']) ? clamp_rating((float)$_GET['min']) : RATING_MIN;
$maxRating = isset($_GET['max']) ? clamp_rating((float)$_GET['max']) : RATING_MAX;
if ($minRating > $maxRating) { [$minRating, $maxRating] = [$maxRating, $minRating]; }
$sort = $_GET['sort'] ?? 'rating';

$filterGenres = get_genres_for_type($filterType);
$items = filter_items($filterType, $selectedGenres, $minRating, $maxRating, null, $sort, 90);

if (is_ajax() || isset($_GET['ajax'])) {
    header('Content-Type: text/html; charset=UTF-8');
    $emptyMessage = 'No games found for these filters.';
    include __DIR__ . '/includes/item_grid.php';
    exit;
}

$pageTitle = 'Games';
$activeNav = 'games';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/filter_panel.php';
?>

<div class="content-header">
  <div>
    <h1>Games</h1>
    <p class="content-sub"><?php echo count($items); ?> results<?php if ($selectedGenres): ?> &bull; <?php echo e(implode(', ', $selectedGenres)); ?><?php endif; ?></p>
  </div>
  <button type="button" class="btn btn-outline" id="openFilters">&#9881; Filters</button>
</div>

<div id="resultsContainer">
  <?php $emptyMessage = 'No games found for these filters.'; include __DIR__ . '/includes/item_grid.php'; ?>
</div>

<?php
$extraScripts = ['assets/js/filters.js'];
require_once __DIR__ . '/includes/footer.php';
