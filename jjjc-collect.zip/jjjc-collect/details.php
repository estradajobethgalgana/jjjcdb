<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login();

$type = $_GET['type'] ?? '';
$id   = (int)($_GET['id'] ?? 0);

if (!valid_item_type($type) || $id <= 0) {
    http_response_code(404);
    $pageTitle = 'Not Found';
    require_once __DIR__ . '/includes/header.php';
    echo '<p class="empty-state">That title could not be found.</p>';
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

$item = get_item($type, $id);
if (!$item) {
    http_response_code(404);
    $pageTitle = 'Not Found';
    require_once __DIR__ . '/includes/header.php';
    echo '<p class="empty-state">That title could not be found.</p>';
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_login();
    $uid = current_user_id();
    $action = $_GET['action'] ?? $_POST['action'] ?? '';

    if ($action === 'delete_review') {
        $reviewId = (int)($_POST['review_id'] ?? 0);
        if ($reviewId > 0 && delete_review($uid, $reviewId)) {
            flash_set('flash_success', 'Your review was deleted.');
        } else {
            flash_set('flash_error', 'Could not delete that review.');
        }
    } else {
        $rating = clamp_rating((float)($_POST['rating'] ?? 0));
        $text   = clean_str($_POST['review_text'] ?? '');
        if ($rating < 0.5) {
            flash_set('flash_error', 'Please choose a rating of at least 0.5 stars.');
        } elseif ($text === '') {
            flash_set('flash_error', 'Review text is required.');
        } elseif (mb_strlen($text) > 3000) {
            flash_set('flash_error', 'Review text is too long (max 3000 characters).');
        } else {
            upsert_review($uid, $type, $id, $rating, $text);
            flash_set('flash_success', 'Your review was saved.');
        }
    }
    redirect('details.php?type=' . urlencode($type) . '&id=' . $id . '#reviews');
}

$pageTitle = $item['title'];
$activeNav = $type === 'movie' ? 'movies' : 'games';
$me = current_user();
$myReview = $me ? get_user_review($me['id'], $type, $id) : null;
$reviews  = get_reviews_for_item($type, $id);
$avgUserRating = get_average_user_rating($type, $id);
$inCollection = $me ? is_in_collection($me['id'], $type, $id) : false;
$backdrop = $item['backdrop_url'] ?: placeholder_image($type . $id . '-bg', 1280, 500);
$poster   = $item['image'] ?: placeholder_image($type . $id, 400, 600);

require_once __DIR__ . '/includes/header.php';
?>

<div class="details-hero" style="background-image:url('<?= e($backdrop) ?>')">
  <div class="details-hero-overlay"></div>
</div>

<div class="details-body">
  <div class="details-poster">
    <img src="<?= e($poster) ?>" alt="<?= e($item['title']) ?>">
    <button type="button" class="btn btn-primary collection-btn full-width <?= $inCollection ? 'in-collection' : '' ?>"
            data-type="<?= e($type) ?>" data-id="<?= $id ?>" data-in="<?= $inCollection ? '1' : '0' ?>">
      <?= $inCollection ? '&#10003; In Collection' : '+ Collection' ?>
    </button>
  </div>

  <div class="details-info">
    <h1><?= e($item['title']) ?></h1>
    <p class="details-meta">
      <?= e((string)$item['release_year']) ?>
      <?php if (!empty($item['genres'])): ?>
        &bull; <?= e(implode(' &bull; ', array_map(fn($g) => $g['name'], $item['genres']))) ?>
      <?php endif; ?>
    </p>

    <div class="rating-row">
      <div class="rating-box">
        <span class="rating-label">External Rating</span>
        <?= render_stars((float)$item['external_rating']) ?>
        <span class="rating-value"><?= number_format((float)$item['external_rating'], 1) ?> / 5</span>
        <span class="rating-source"><?= e($item['external_rating_source']) ?><?= $item['external_rating_count'] ? ' &bull; ' . number_format((int)$item['external_rating_count']) . ' ratings' : '' ?></span>
      </div>
      <div class="rating-box">
        <span class="rating-label">Your Rating</span>
        <?php if ($myReview): ?>
          <?= render_stars((float)$myReview['rating']) ?>
          <span class="rating-value"><?= number_format((float)$myReview['rating'], 1) ?> / 5</span>
        <?php else: ?>
          <span class="rating-value muted">Not Rated</span>
        <?php endif; ?>
      </div>
      <?php if ($avgUserRating !== null): ?>
      <div class="rating-box">
        <span class="rating-label">Community Average</span>
        <?= render_stars($avgUserRating) ?>
        <span class="rating-value"><?= number_format($avgUserRating, 1) ?> / 5</span>
        <span class="rating-source"><?= count($reviews) ?> review<?= count($reviews) === 1 ? '' : 's' ?></span>
      </div>
      <?php endif; ?>
    </div>

    <h2 class="section-label">Description</h2>
    <p class="details-description"><?= nl2br(e($item['description'] ?? 'No description available.')) ?></p>
  </div>
</div>

<section class="content-section" id="reviews">
  <div class="section-header"><h2>Reviews</h2></div>

  <?php if ($me): ?>
    <form method="post" action="details.php?type=<?= e($type) ?>&id=<?= $id ?>" class="review-form" id="reviewForm" novalidate>
      <input type="hidden" name="action" value="save_review">
      <label for="reviewRating">Your Rating</label>
      <?php $curRating = $myReview ? (float)$myReview['rating'] : 0; ?>
      <div class="star-picker" id="starPicker">
        <?php for ($i = 1; $i <= 5; $i++): ?>
          <?php
            if ($curRating >= $i) { $fillPct = 100; }
            elseif ($curRating >= $i - 0.5) { $fillPct = 50; }
            else { $fillPct = 0; }
          ?>
          <span class="star-slot" data-star="<?= $i ?>">
            <span class="star-bg">&#9733;</span>
            <span class="star-fg" style="width:<?= $fillPct ?>%">&#9733;</span>
            <button type="button" class="star-half star-half-left" data-value="<?= $i - 0.5 ?>" aria-label="Rate <?= $i - 0.5 ?> out of 5 stars"></button>
            <button type="button" class="star-half star-half-right" data-value="<?= $i ?>" aria-label="Rate <?= $i ?> out of 5 stars"></button>
          </span>
        <?php endfor; ?>
        <span class="star-readout" id="starReadout"><?= $curRating > 0 ? number_format($curRating, 1) . ' / 5' : 'Not rated yet' ?></span>
      </div>
      <input type="hidden" id="reviewRatingValue" name="rating" value="<?= e((string)$curRating) ?>">
      <p class="field-error" id="ratingError">Please choose a rating of at least 0.5 stars.</p>

      <label for="reviewText">Review</label>
      <textarea id="reviewText" name="review_text" rows="4" maxlength="3000" required placeholder="What did you think?"><?= e($myReview['review_text'] ?? '') ?></textarea>
      <p class="field-error" id="reviewTextError">Please write a few words before posting.</p>

      <div class="filter-actions">
        <button type="submit" class="btn btn-primary"><?= $myReview ? 'Update Review' : 'Post Review' ?></button>
      </div>
    </form>
  <?php else: ?>
    <p class="empty-state"><a href="login.php">Log in</a> to write a review.</p>
  <?php endif; ?>

  <div class="review-list">
    <?php if (empty($reviews)): ?>
      <p class="empty-state">No reviews yet. Be the first to review this <?= $type === 'movie' ? 'movie' : 'game' ?>!</p>
    <?php endif; ?>
    <?php foreach ($reviews as $r): ?>
      <article class="review-item">
        <img src="<?= e($r['avatar'] ? AVATAR_UPLOAD_URL . $r['avatar'] : 'assets/img/default-avatar.svg') ?>" alt="" class="avatar-sm">
        <div class="review-body">
          <div class="review-head">
            <strong><?= e($r['username']) ?></strong>
            <?= render_stars((float)$r['rating']) ?>
            <time><?= date('F j, Y', strtotime($r['created_at'])) ?></time>
          </div>
          <p><?= nl2br(e($r['review_text'])) ?></p>
          <?php if ($me && (int)$r['user_id'] === (int)$me['id']): ?>
            <form method="post" action="details.php?type=<?= e($type) ?>&id=<?= $id ?>&action=delete_review" onsubmit="return confirm('Delete this review?');" class="inline-form">
              <input type="hidden" name="review_id" value="<?= (int)$r['id'] ?>">
              <button type="submit" class="btn btn-sm btn-outline danger">Delete</button>
            </form>
          <?php endif; ?>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<script>
(function () {
  var form = document.getElementById('reviewForm');
  if (!form) return;
  var ratingInput = document.getElementById('reviewRatingValue');
  var ratingError = document.getElementById('ratingError');
  var textInput = document.getElementById('reviewText');
  var textError = document.getElementById('reviewTextError');

  form.addEventListener('submit', function (e) {
    var ratingOk = parseFloat(ratingInput.value) >= 0.5;
    var textOk = textInput.value.trim().length > 0;
    ratingError.classList.toggle('show', !ratingOk);
    textInput.classList.toggle('invalid', !textOk);
    textError.classList.toggle('show', !textOk);
    if (!ratingOk || !textOk) {
      e.preventDefault();
    }
  });

  textInput.addEventListener('input', function () {
    textInput.classList.remove('invalid');
    textError.classList.remove('show');
  });
})();
</script>

<?php
$extraScripts = ['assets/js/review-stars.js'];
require_once __DIR__ . '/includes/footer.php';
?>
