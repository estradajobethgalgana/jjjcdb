<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login();
$me = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_review') {
    $reviewId = (int)($_POST['review_id'] ?? 0);
    if ($reviewId > 0 && delete_review($me['id'], $reviewId)) {
        flash_set('flash_success', 'Review deleted.');
    } else {
        flash_set('flash_error', 'Could not delete that review.');
    }
    redirect('reviews.php');
}

$myReviews = get_user_reviews($me['id']);

$pageTitle = 'My Reviews';
require_once __DIR__ . '/includes/header.php';
?>

<div class="content-header">
  <div>
    <h1>My Reviews</h1>
    <p class="content-sub"><?= count($myReviews) ?> review<?= count($myReviews) === 1 ? '' : 's' ?></p>
  </div>
</div>

<?php if (empty($myReviews)): ?>
  <p class="empty-state">You haven't written any reviews yet.</p>
<?php else: ?>
  <div class="review-list">
    <?php foreach ($myReviews as $r): ?>
      <?php $item = $r['item']; if (!$item) continue; ?>
      <article class="review-item review-item-mine">
        <img src="<?= e($item['image'] ?: placeholder_image($r['item_type'].$r['item_id'], 100, 150)) ?>" alt="" class="review-thumb">
        <div class="review-body">
          <div class="review-head">
            <a href="details.php?type=<?= e($r['item_type']) ?>&id=<?= (int)$r['item_id'] ?>"><strong><?= e($item['title']) ?></strong></a>
            <?= render_stars((float)$r['rating']) ?>
            <time><?= date('F j, Y', strtotime($r['created_at'])) ?></time>
          </div>
          <p><?= nl2br(e($r['review_text'])) ?></p>
          <div class="review-actions">
            <a href="details.php?type=<?= e($r['item_type']) ?>&id=<?= (int)$r['item_id'] ?>#reviews" class="btn btn-sm btn-outline">Edit</a>
            <form method="post" action="reviews.php" onsubmit="return confirm('Delete this review?');" class="inline-form">
              <input type="hidden" name="action" value="delete_review">
              <input type="hidden" name="review_id" value="<?= (int)$r['id'] ?>">
              <button type="submit" class="btn btn-sm btn-outline danger">Delete</button>
            </form>
          </div>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
