<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login();

$pageTitle = 'Top 10';
$activeNav = 'top10';

$topMovies = top10('movie');
$topGames  = top10('game');

require_once __DIR__ . '/includes/header.php';
?>

<div class="content-header">
  <div>
    <h1>Top 10</h1>
    <p class="content-sub">Ranked by external rating (and rating count as a tiebreaker).</p>
  </div>
</div>

<section class="content-section" id="movies">
  <div class="section-header"><h2>&#127916; Top 10 Movies</h2></div>
  <?php $items = $topMovies; $emptyMessage = 'No movies yet.'; $carouselId = 'top10PageMovies'; include __DIR__ . '/includes/carousel.php'; ?>
</section>

<section class="content-section" id="games">
  <div class="section-header"><h2>&#127918; Top 10 Games</h2></div>
  <?php $items = $topGames; $emptyMessage = 'No games yet.'; $carouselId = 'top10PageGames'; include __DIR__ . '/includes/carousel.php'; ?>
</section>

<?php
$extraScripts = ['assets/js/carousel.js'];
require_once __DIR__ . '/includes/footer.php';
?>
