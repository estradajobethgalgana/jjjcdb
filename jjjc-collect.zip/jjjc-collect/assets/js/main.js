document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  var navToggle = document.getElementById('mobileNavToggle');
  var sidebar = document.getElementById('sidebar');
  if (navToggle && sidebar) {
    navToggle.addEventListener('click', function () {
      var open = sidebar.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.addEventListener('click', function (e) {
      if (sidebar.classList.contains('open') &&
          !sidebar.contains(e.target) && !navToggle.contains(e.target)) {
        sidebar.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  var profileBtn = document.getElementById('profileBtn');
  var profileDropdown = document.getElementById('profileDropdown');
  if (profileBtn && profileDropdown) {
    profileBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      var isOpen = profileDropdown.classList.toggle('open');
      profileBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
    document.addEventListener('click', function (e) {
      if (!profileDropdown.contains(e.target) && !profileBtn.contains(e.target)) {
        profileDropdown.classList.remove('open');
        profileBtn.setAttribute('aria-expanded', 'false');
      }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        profileDropdown.classList.remove('open');
        profileBtn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  window.showToast = function (message, isError) {
    var container = document.getElementById('toastContainer');
    if (!container) return;
    var toast = document.createElement('div');
    toast.className = 'toast' + (isError ? ' error' : '');
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(function () {
      toast.remove();
    }, 3200);
  };

  document.querySelectorAll('.nav-movies, .nav-games').forEach(function (link) {
    link.addEventListener('click', function (e) {
      var target = link.getAttribute('data-filter-page');
      var onSamePage = window.location.pathname.endsWith(target);
      var panel = document.getElementById('filterPanel');
      if (onSamePage && panel) {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent('jjjc:openFilters'));
        if (sidebar) {
          sidebar.classList.remove('open');
        }
      }

    });
  });

  document.body.addEventListener('click', function (e) {
    var btn = e.target.closest('.collection-btn');
    if (!btn) return;
    e.preventDefault();

    var type = btn.getAttribute('data-type');
    var id = btn.getAttribute('data-id');
    var currentlyIn = btn.getAttribute('data-in') === '1';
    var op = currentlyIn ? 'remove' : 'add';

    var formData = new FormData();
    formData.append('type', type);
    formData.append('id', id);
    formData.append('op', op);

    btn.disabled = true;

    fetch('api/collection_action.php', {
      method: 'POST',
      body: formData,
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
      .then(function (res) { return res.json().then(function (data) { return { status: res.status, data: data }; }); })
      .then(function (result) {
        var data = result.data;
        if (result.status === 401) {
          showToast(data.message || 'Please log in to add this item to your collection.', true);
          return;
        }
        if (!data.ok) {
          showToast(data.message || 'Something went wrong.', true);
          return;
        }

        document.querySelectorAll('.collection-btn[data-type="' + type + '"][data-id="' + id + '"]').forEach(function (b) {
          b.setAttribute('data-in', data.in_collection ? '1' : '0');
          b.classList.toggle('in-collection', data.in_collection);
          b.innerHTML = data.in_collection ? '&#10003; In Collection' : '+ Collection';
        });
        showToast(data.message);
      })
      .catch(function () {
        showToast('Network error — please try again.', true);
      })
      .finally(function () {
        btn.disabled = false;
      });
  });
});
