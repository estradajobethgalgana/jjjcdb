document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  var panel = document.getElementById('filterPanel');
  var backdrop = document.getElementById('filterBackdrop');
  if (!panel) return;

  var openBtn = document.getElementById('openFilters');
  var closeBtn = document.getElementById('filterClose');
  var form = document.getElementById('filterForm');
  var resetBtn = document.getElementById('resetFilters');
  var resultsContainer = document.getElementById('resultsContainer');
  var itemType = panel.getAttribute('data-type');
  var pageUrl = itemType === 'movie' ? 'movies.php' : 'games.php';

  function openPanel() {
    panel.classList.add('open');
    backdrop.classList.add('open');
    panel.setAttribute('aria-hidden', 'false');
    var firstInput = panel.querySelector('input');
    if (firstInput) firstInput.focus();
  }
  function closePanel() {
    panel.classList.remove('open');
    backdrop.classList.remove('open');
    panel.setAttribute('aria-hidden', 'true');
  }

  if (openBtn) openBtn.addEventListener('click', openPanel);
  if (closeBtn) closeBtn.addEventListener('click', closePanel);
  if (backdrop) backdrop.addEventListener('click', closePanel);
  window.addEventListener('jjjc:openFilters', openPanel);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && panel.classList.contains('open')) closePanel();
  });

  var minInput = document.getElementById('minRating');
  var maxInput = document.getElementById('maxRating');
  var minLabel = document.getElementById('minRatingLabel');
  var maxLabel = document.getElementById('maxRatingLabel');
  var sliderRange = document.getElementById('sliderRange');

  function updateSliderVisual() {
    var min = parseFloat(minInput.min), max = parseFloat(minInput.max);
    var minVal = parseFloat(minInput.value), maxVal = parseFloat(maxInput.value);
    var minPct = ((minVal - min) / (max - min)) * 100;
    var maxPct = ((maxVal - min) / (max - min)) * 100;
    sliderRange.style.left = minPct + '%';
    sliderRange.style.width = Math.max(0, maxPct - minPct) + '%';
    minLabel.innerHTML = '&#9733; ' + minVal.toFixed(1);
    maxLabel.innerHTML = '&#9733; ' + maxVal.toFixed(1);
  }

  if (minInput && maxInput) {
    minInput.addEventListener('input', function () {
      if (parseFloat(minInput.value) > parseFloat(maxInput.value)) {
        minInput.value = maxInput.value;
      }
      updateSliderVisual();
    });
    maxInput.addEventListener('input', function () {
      if (parseFloat(maxInput.value) < parseFloat(minInput.value)) {
        maxInput.value = minInput.value;
      }
      updateSliderVisual();
    });
    updateSliderVisual();
  }

  function buildQuery() {
    var params = new URLSearchParams();
    form.querySelectorAll('input[name="genre[]"]:checked').forEach(function (cb) {
      params.append('genre[]', cb.value);
    });
    params.set('min', minInput.value);
    params.set('max', maxInput.value);
    return params;
  }

  function applyFilters(pushState) {
    var params = buildQuery();
    var queryString = params.toString();

    resultsContainer.setAttribute('aria-busy', 'true');

    fetch(pageUrl + '?' + queryString, {
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
      .then(function (res) { return res.text(); })
      .then(function (html) {
        resultsContainer.innerHTML = html;
        if (pushState !== false) {
          history.pushState({}, '', pageUrl + '?' + queryString);
        }
      })
      .catch(function () {
        showToast('Could not load filtered results.', true);
      })
      .finally(function () {
        resultsContainer.removeAttribute('aria-busy');
      });
  }

  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      applyFilters(true);
      closePanel();
    });
  }

  if (resetBtn) {
    resetBtn.addEventListener('click', function () {
      form.querySelectorAll('input[name="genre[]"]').forEach(function (cb) { cb.checked = false; });
      minInput.value = minInput.min;
      maxInput.value = maxInput.max;
      updateSliderVisual();
      applyFilters(true);
    });
  }

  window.addEventListener('popstate', function () {
    window.location.reload();
  });
});
