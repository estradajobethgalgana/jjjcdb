document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  document.querySelectorAll('.carousel-wrap').forEach(function (wrap) {
    var viewport = wrap.querySelector('.carousel-viewport');
    var track = wrap.querySelector('.carousel-track');
    var items = Array.prototype.slice.call(track.children);
    var prevBtn = wrap.querySelector('.carousel-prev');
    var nextBtn = wrap.querySelector('.carousel-next');
    var dotsWrap = wrap.querySelector('.carousel-dots');
    if (items.length === 0) return;

    var currentPage = 0;
    var autoTimer = null;
    var gap = 18;

    function itemsPerView() {
      var w = viewport.clientWidth;
      if (w < 480) return 1;
      if (w < 700) return 2;
      if (w < 960) return 3;
      if (w < 1200) return 4;
      if (w < 1500) return 5;
      return 6;
    }

    function pageCount(perView) {
      return Math.max(1, Math.ceil(items.length / perView));
    }

    function layout() {
      var perView = itemsPerView();
      var viewportWidth = viewport.clientWidth;
      var itemWidth = (viewportWidth - gap * (perView - 1)) / perView;

      items.forEach(function (item) {
        item.style.flex = '0 0 ' + itemWidth + 'px';
      });

      var pages = pageCount(perView);
      if (currentPage >= pages) {
        currentPage = pages - 1;
      }
      renderDots(pages);
      goToPage(currentPage, perView, itemWidth, false);
    }

    function renderDots(pages) {
      dotsWrap.innerHTML = '';
      if (pages <= 1) return;
      for (var i = 0; i < pages; i++) {
        var dot = document.createElement('button');
        dot.type = 'button';
        dot.className = 'dot' + (i === currentPage ? ' active' : '');
        dot.setAttribute('aria-label', 'Go to slide ' + (i + 1));
        dot.setAttribute('data-page', i);
        dotsWrap.appendChild(dot);
      }
    }

    function updateDots() {
      Array.prototype.slice.call(dotsWrap.children).forEach(function (dot, i) {
        dot.classList.toggle('active', i === currentPage);
      });
    }

    function updateArrows(pages) {
      if (!prevBtn || !nextBtn) return;
      var disable = pages <= 1;
      prevBtn.disabled = disable;
      nextBtn.disabled = disable;
    }

    function goToPage(page, perView, itemWidth, animate) {
      var pages = pageCount(perView);
      currentPage = (page + pages) % pages;
      var offset = currentPage * perView * (itemWidth + gap);
      track.style.transition = animate === false ? 'none' : '';
      track.style.transform = 'translateX(-' + offset + 'px)';
      if (animate === false) {
        void track.offsetHeight;
        track.style.transition = '';
      }
      updateDots();
      updateArrows(pages);
    }

    function next() {
      var perView = itemsPerView();
      var itemWidth = (viewport.clientWidth - gap * (perView - 1)) / perView;
      goToPage(currentPage + 1, perView, itemWidth);
    }

    function prev() {
      var perView = itemsPerView();
      var itemWidth = (viewport.clientWidth - gap * (perView - 1)) / perView;
      goToPage(currentPage - 1, perView, itemWidth);
    }

    function startAuto() {
      stopAuto();
      autoTimer = setInterval(next, 5000);
    }
    function stopAuto() {
      if (autoTimer) clearInterval(autoTimer);
    }

    if (nextBtn) nextBtn.addEventListener('click', function () { next(); startAuto(); });
    if (prevBtn) prevBtn.addEventListener('click', function () { prev(); startAuto(); });

    dotsWrap.addEventListener('click', function (e) {
      var dot = e.target.closest('.dot');
      if (!dot) return;
      var perView = itemsPerView();
      var itemWidth = (viewport.clientWidth - gap * (perView - 1)) / perView;
      goToPage(parseInt(dot.getAttribute('data-page'), 10), perView, itemWidth);
      startAuto();
    });

    wrap.addEventListener('mouseenter', stopAuto);
    wrap.addEventListener('mouseleave', startAuto);

    var resizeTimer = null;
    window.addEventListener('resize', function () {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(layout, 150);
    });

    layout();
    startAuto();
  });
});
