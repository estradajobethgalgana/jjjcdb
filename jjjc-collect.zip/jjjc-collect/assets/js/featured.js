document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  var featured = document.getElementById('featured');
  if (!featured) return;

  var slides = Array.prototype.slice.call(featured.querySelectorAll('.featured-slide'));
  var dots = Array.prototype.slice.call(featured.querySelectorAll('.dot'));
  var prevBtn = document.getElementById('featuredPrev');
  var nextBtn = document.getElementById('featuredNext');
  if (slides.length <= 1) return;

  var current = 0;
  var ROTATE_MS = 12000;
  var timer = null;

  function show(index) {
    slides[current].classList.remove('active');
    if (dots[current]) dots[current].classList.remove('active');
    current = (index + slides.length) % slides.length;
    slides[current].classList.add('active');
    if (dots[current]) dots[current].classList.add('active');
  }

  function next() { show(current + 1); }
  function prev() { show(current - 1); }

  function startAuto() {
    stopAuto();
    timer = setInterval(next, ROTATE_MS);
  }
  function stopAuto() {
    if (timer) clearInterval(timer);
  }

  if (nextBtn) nextBtn.addEventListener('click', function () { next(); startAuto(); });
  if (prevBtn) prevBtn.addEventListener('click', function () { prev(); startAuto(); });
  dots.forEach(function (dot, i) {
    dot.addEventListener('click', function () { show(i); startAuto(); });
  });

  featured.addEventListener('mouseenter', stopAuto);
  featured.addEventListener('mouseleave', startAuto);

  startAuto();
});
