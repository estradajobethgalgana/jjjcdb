document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  var picker = document.getElementById('starPicker');
  if (!picker) return;

  var hiddenInput = document.getElementById('reviewRatingValue');
  var readout = document.getElementById('starReadout');
  var slots = Array.prototype.slice.call(picker.querySelectorAll('.star-slot'));
  var committedValue = parseFloat(hiddenInput.value) || 0;

  function paint(value) {
    slots.forEach(function (slot) {
      var starNum = parseInt(slot.getAttribute('data-star'), 10);
      var fg = slot.querySelector('.star-fg');
      var pct = 0;
      if (value >= starNum) {
        pct = 100;
      } else if (value >= starNum - 0.5) {
        pct = 50;
      }
      fg.style.width = pct + '%';
    });
  }

  function updateReadout(value) {
    readout.textContent = value > 0 ? value.toFixed(1) + ' / 5' : 'Not rated yet';
  }

  picker.addEventListener('mouseover', function (e) {
    var half = e.target.closest('.star-half');
    if (!half) return;
    paint(parseFloat(half.getAttribute('data-value')));
  });

  picker.addEventListener('mouseleave', function () {
    paint(committedValue);
  });

  picker.addEventListener('click', function (e) {
    var half = e.target.closest('.star-half');
    if (!half) return;
    committedValue = parseFloat(half.getAttribute('data-value'));
    hiddenInput.value = committedValue;
    paint(committedValue);
    updateReadout(committedValue);
  });

  picker.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    var half = e.target.closest('.star-half');
    if (!half) return;
    e.preventDefault();
    half.click();
  });
});
