<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

logout_user();
session_start();
flash_set('flash_success', 'You have been logged out.');
redirect('index.php');
