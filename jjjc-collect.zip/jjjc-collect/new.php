<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login();

$pageTitle = 'New';
$activeNav = 'new';

$newMovies = newest('movie', 24);
$newGames  = newest('game', 24);

require_once __DIR__ . '/includes/header.php';
?>

<div class="content-header">
  <div>
    <h1>New</h1>
    <p class="content-sub">Recently released movies and games, newest first.</p>
  </div>
</div>

<section class="content-section">
  <div class="section-header"><h2>&#127916; New Movies</h2></div>
  <?php $items = $newMovies; $emptyMessage = 'No movies yet.'; include __DIR__ . '/includes/item_grid.php'; ?>
</section>

<section class="content-section">
  <div class="section-header"><h2>&#127918; New Games</h2></div>
  <?php $items = $newGames; $emptyMessage = 'No games yet.'; include __DIR__ . '/includes/item_grid.php'; ?>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
