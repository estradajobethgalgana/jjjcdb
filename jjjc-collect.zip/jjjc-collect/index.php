<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login();

$pageTitle = 'Home';
$activeNav = 'home';

$featured   = get_featured_candidates(6);
$topMovies  = top10('movie');
$topGames   = top10('game');
$newMovies  = newest('movie', 6);
$newGames   = newest('game', 6);
$newest     = array_merge($newMovies, $newGames);
usort($newest, fn($a, $b) => strcmp($b['release_date'] ?? '', $a['release_date'] ?? ''));
$newest = array_slice($newest, 0, 10);

require_once __DIR__ . '/includes/header.php';
?>

<section class="featured" id="featured" aria-label="Featured movie or game">
  <?php if ($featured): ?>
    <?php foreach ($featured as $i => $f): ?>
      <div class="featured-slide <?= $i === 0 ? 'active' : '' ?>" data-index="<?= $i ?>"
           style="background-image:url('<?= e($f['image'] ?: placeholder_image($f['item_type'].$f['id'], 1280, 720)) ?>')">
        <div class="featured-overlay">
          <span class="featured-badge">
            <?= $f['item_type'] === 'movie' ? '&#127916; FEATURED MOVIE' : '&#127918; FEATURED GAME' ?>
          </span>
          <h2 class="featured-title"><?= e($f['title']) ?></h2>
          <p class="featured-meta">
            <?= e((string)$f['release_year']) ?>
            <?php if (!empty($f['genres'])): ?>
              &bull; <?= e(implode(' &bull; ', array_map(fn($g) => $g['name'], array_slice($f['genres'], 0, 3)))) ?>
            <?php endif; ?>
          </p>
          <p class="featured-rating">&#9733; <?= number_format((float)$f['external_rating'], 1) ?> / 5
            <span class="rating-source"><?= e($f['external_rating_source']) ?></span></p>
          <p class="featured-desc"><?= e(mb_strimwidth($f['description'] ?? '', 0, 180, '…')) ?></p>
          <div class="featured-actions">
            <a href="details.php?type=<?= e($f['item_type']) ?>&id=<?= (int)$f['id'] ?>" class="btn btn-primary btn-lg">View Details</a>
            <button type="button" class="btn btn-outline collection-btn" data-type="<?= e($f['item_type']) ?>" data-id="<?= (int)$f['id'] ?>" data-in="<?= (current_user_id() && is_in_collection(current_user_id(), $f['item_type'], $f['id'])) ? '1' : '0' ?>">
              + Collection
            </button>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
    <div class="featured-controls">
      <button type="button" class="featured-prev" id="featuredPrev" aria-label="Previous featured item">&#10094;</button>
      <div class="featured-dots" id="featuredDots" role="tablist">
        <?php foreach ($featured as $i => $f): ?>
          <button type="button" class="dot <?= $i === 0 ? 'active' : '' ?>" data-index="<?= $i ?>" aria-label="Show featured item <?= $i + 1 ?>"></button>
        <?php endforeach; ?>
      </div>
      <button type="button" class="featured-next" id="featuredNext" aria-label="Next featured item">&#10095;</button>
    </div>
  <?php else: ?>
    <p class="empty-state">No featured content yet — seed the database to get started.</p>
  <?php endif; ?>
</section>

<section class="content-section">
  <div class="section-header">
    <h2>Top 10 Movies</h2>
    <a href="top10.php#movies" class="see-all">See all &rarr;</a>
  </div>
  <?php $items = $topMovies; $emptyMessage = 'No movies yet.'; $carouselId = 'homeTopMovies'; include __DIR__ . '/includes/carousel.php'; ?>
</section>

<section class="content-section">
  <div class="section-header">
    <h2>Top 10 Games</h2>
    <a href="top10.php#games" class="see-all">See all &rarr;</a>
  </div>
  <?php $items = $topGames; $emptyMessage = 'No games yet.'; $carouselId = 'homeTopGames'; include __DIR__ . '/includes/carousel.php'; ?>
</section>

<section class="content-section">
  <div class="section-header">
    <h2>New Movies &amp; Games</h2>
    <a href="new.php" class="see-all">See all &rarr;</a>
  </div>
  <?php $items = $newest; $emptyMessage = 'Nothing new yet.'; include __DIR__ . '/includes/item_grid.php'; ?>
</section>

<?php
$extraScripts = ['assets/js/featured.js', 'assets/js/carousel.js'];
require_once __DIR__ . '/includes/footer.php';
