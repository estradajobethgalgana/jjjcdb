<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login();
$me = current_user();
$tab = $_GET['tab'] ?? 'all';
$type = $tab === 'movies' ? 'movie' : ($tab === 'games' ? 'game' : null);

$items = get_user_collection($me['id'], $type);

$pageTitle = 'My Collection';
require_once __DIR__ . '/includes/header.php';
?>

<div class="content-header">
  <div>
    <h1>My Collection</h1>
    <p class="content-sub"><?= count($items) ?> item<?= count($items) === 1 ? '' : 's' ?></p>
  </div>
</div>

<div class="tabs">
  <a href="collection.php?tab=all" class="tab <?= $tab === 'all' ? 'active' : '' ?>">All</a>
  <a href="collection.php?tab=movies" class="tab <?= $tab === 'movies' ? 'active' : '' ?>">Movies</a>
  <a href="collection.php?tab=games" class="tab <?= $tab === 'games' ? 'active' : '' ?>">Games</a>
</div>

<?php $emptyMessage = 'Your collection is empty.'; include __DIR__ . '/includes/item_grid.php'; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
