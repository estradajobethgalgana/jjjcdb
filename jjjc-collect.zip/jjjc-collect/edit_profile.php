<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login();
$me = current_user();
$errors = [];
$bio = $me['bio'] ?? '';
$username = $me['username'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = clean_str($_POST['username'] ?? $me['username']);
    $bio = clean_str($_POST['bio'] ?? '');

    if (!preg_match('/^[a-zA-Z0-9_]{3,30}$/', $username)) {
        $errors[] = 'Username must be 3-30 characters (letters, numbers, underscore only).';
    }
    if (mb_strlen($bio) > 500) {
        $errors[] = 'Bio must be 500 characters or fewer.';
    }

    $db = Database::getConnection();

    if (empty($errors) && $username !== $me['username']) {
        $chk = $db->prepare('SELECT id FROM users WHERE username = ? AND id != ?');
        $chk->execute([$username, $me['id']]);
        if ($chk->fetch()) {
            $errors[] = 'That username is already taken.';
        }
    }

    $newAvatarFilename = null;
    if (empty($errors) && !empty($_FILES['avatar']['name'])) {
        $file = $_FILES['avatar'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'There was a problem uploading that file.';
        } elseif ($file['size'] > AVATAR_MAX_SIZE) {
            $errors[] = 'Image must be smaller than 2MB.';
        } else {
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);

            if (!in_array($ext, AVATAR_ALLOWED_EXT, true) || !in_array($mime, AVATAR_ALLOWED_MIME, true)) {
                $errors[] = 'Only JPG, PNG, or WEBP images are allowed.';
            } elseif (@getimagesize($file['tmp_name']) === false) {
                $errors[] = 'That file is not a valid image.';
            } else {
                $newAvatarFilename = 'user_' . $me['id'] . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
                $destination = AVATAR_UPLOAD_DIR . $newAvatarFilename;
                if (!move_uploaded_file($file['tmp_name'], $destination)) {
                    $errors[] = 'Could not save the uploaded image.';
                    $newAvatarFilename = null;
                }
            }
        }
    }

    if (empty($errors)) {
        if ($newAvatarFilename) {

            if (!empty($me['avatar']) && is_file(AVATAR_UPLOAD_DIR . $me['avatar'])) {
                @unlink(AVATAR_UPLOAD_DIR . $me['avatar']);
            }
            $stmt = $db->prepare('UPDATE users SET username = ?, bio = ?, avatar = ? WHERE id = ?');
            $stmt->execute([$username, $bio, $newAvatarFilename, $me['id']]);
        } else {
            $stmt = $db->prepare('UPDATE users SET username = ?, bio = ? WHERE id = ?');
            $stmt->execute([$username, $bio, $me['id']]);
        }
        flash_set('flash_success', 'Profile updated.');
        redirect('profile.php');
    }
}

$pageTitle = 'Edit Profile';
$extraStyles = ['assets/css/bio-profile.css'];
require_once __DIR__ . '/includes/header.php';
?>

<div class="bio-page-wrap">
  <a href="profile.php" class="btn-back">&larr; BACK</a>

  <div class="edit-page-card">
    <h2>Edit Profile</h2>

    <?php foreach ($errors as $err): ?>
      <p class="flash flash-error"><?= e($err) ?></p>
    <?php endforeach; ?>

    <form method="post" action="edit_profile.php" enctype="multipart/form-data" class="edit-form" id="editProfileForm" novalidate>

      <div class="edit-section">
        <div class="profile-pic-edit">
          <img src="<?= e($me['avatar'] ? AVATAR_UPLOAD_URL . $me['avatar'] : 'assets/img/default-avatar.svg') ?>" alt="Profile" id="avatarPreview">
        </div>
        <p class="edit-label">CHANGE PROFILE PICTURE</p>
        <input type="file" id="avatar" name="avatar" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp">
        <p class="field-error" id="avatarError">Only JPG, PNG, or WEBP images under 2MB are allowed.</p>
      </div>

      <div class="form-group">
        <label for="username">EDIT USERNAME</label>
        <input type="text" id="username" name="username" required value="<?= e($username) ?>">
        <p class="field-error" id="usernameError">3-30 characters: letters, numbers, and underscore only.</p>
      </div>

      <div class="form-group">
        <label for="email">EMAIL</label>
        <input type="email" id="email" value="<?= e($me['email']) ?>" readonly>
      </div>

      <div class="form-group">
        <label for="bio">EDIT BIO</label>
        <textarea id="bio" name="bio" rows="5" maxlength="500" placeholder="Tell us about yourself..."><?= e($bio) ?></textarea>
      </div>

      <div class="character-count" id="charCount">0/500</div>

      <button type="submit" class="btn-save">SAVE</button>
    </form>
  </div>
</div>

<script>
  var bioInput = document.getElementById('bio');
  var charCount = document.getElementById('charCount');
  function updateCharCount() {
    charCount.textContent = bioInput.value.length + '/500';
  }
  bioInput.addEventListener('input', updateCharCount);
  updateCharCount();

  var avatarInput = document.getElementById('avatar');
  var avatarPreview = document.getElementById('avatarPreview');
  var avatarError = document.getElementById('avatarError');
  var allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
  var maxSize = 2 * 1024 * 1024;

  avatarInput.addEventListener('change', function () {
    if (!avatarInput.files || !avatarInput.files[0]) return;
    var file = avatarInput.files[0];
    var ok = allowedTypes.indexOf(file.type) !== -1 && file.size <= maxSize;
    avatarError.classList.toggle('show', !ok);
    if (ok) {
      avatarPreview.src = URL.createObjectURL(file);
    } else {
      avatarInput.value = '';
    }
  });

  var form = document.getElementById('editProfileForm');
  var username = document.getElementById('username');
  var usernameError = document.getElementById('usernameError');

  function isUsername(value) {
    return /^[a-zA-Z0-9_]{3,30}$/.test(value);
  }

  form.addEventListener('submit', function (e) {
    var usernameOk = isUsername(username.value.trim());
    username.classList.toggle('invalid', !usernameOk);
    usernameError.classList.toggle('show', !usernameOk);
    if (!usernameOk) {
      e.preventDefault();
    }
  });

  username.addEventListener('input', function () {
    username.classList.remove('invalid');
    usernameError.classList.remove('show');
  });
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
