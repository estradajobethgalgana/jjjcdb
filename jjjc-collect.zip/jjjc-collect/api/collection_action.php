<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    json_response(['ok' => false, 'error' => 'login_required', 'message' => 'Please log in to add this item to your collection.'], 401);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'message' => 'Invalid request method.'], 405);
}

$type = $_POST['type'] ?? '';
$id   = (int)($_POST['id'] ?? 0);
$op   = $_POST['op'] ?? 'toggle';

if (!valid_item_type($type) || $id <= 0) {
    json_response(['ok' => false, 'message' => 'Invalid item.'], 400);
}

$uid = current_user_id();
$already = is_in_collection($uid, $type, $id);

if ($op === 'add' || ($op === 'toggle' && !$already)) {
    add_to_collection($uid, $type, $id);
    json_response(['ok' => true, 'in_collection' => true, 'message' => 'Added to your collection ✓']);
} elseif ($op === 'remove' || ($op === 'toggle' && $already)) {
    remove_from_collection($uid, $type, $id);
    json_response(['ok' => true, 'in_collection' => false, 'message' => 'Removed from your collection']);
}

json_response(['ok' => false, 'message' => 'No action taken.'], 400);
