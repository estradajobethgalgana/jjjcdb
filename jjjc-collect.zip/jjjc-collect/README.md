# JJJC.Collect

A full-stack Movie + Video Game collection, rating, and review platform
(Letterboxd-style), built in **plain PHP 8 + MySQL** with vanilla
JavaScript — no frameworks required.

---

## 1. Requirements

- PHP 8.0+ with the `pdo_mysql`, `gd` (or `fileinfo`), and `mbstring` extensions
- MySQL 5.7+ or 8.0 (MariaDB 10.4+ also works)
- Any web server that can run PHP: Apache/XAMPP/MAMP/WAMP, or PHP's built-in server

## 2. Setup

1. **Copy the project** into your web root, e.g. `htdocs/jjjc-collect` (XAMPP) or any folder.

2. **Create the database and tables:**
   ```bash
   mysql -u root -p < database/schema.sql
   ```
   (or import `database/schema.sql` through phpMyAdmin)

3. **Configure your database credentials** in `config/config.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'moviegame_db');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   ```

4. **Seed the database** with genres, 39 movies, and 46 games:
   ```bash
   php database/seed.php
   ```
   or visit `http://localhost/jjjc-collect/database/seed.php?confirm=1` in a browser.
   The script is **idempotent** — safe to run again, it will not create duplicates.
   It prints a genre-by-genre verification at the end confirming every
   genre has at least 10 distinct movies/games.

5. **Make the upload folder writable** (for profile pictures):
   ```bash
   chmod -R 775 assets/uploads/avatars
   ```

6. **Run it:**
   - XAMPP/MAMP: visit `http://localhost/jjjc-collect/`
   - PHP built-in server: `php -S localhost:8000` from the project root, then visit `http://localhost:8000/`

## 3. Project structure

```
config/           DB credentials, constants, session bootstrap
includes/         auth.php, functions.php (all data-access helpers), header/footer, filter panel partial
assets/css/       style.css (dark black/gray/green theme, fully responsive)
assets/js/        main.js (nav, dropdown, collection AJAX), filters.js, featured.js, review-stars.js
assets/img/       logo, default avatar
assets/uploads/   user-uploaded avatars (writable)
api/              collection_action.php (AJAX add/remove collection)
database/         schema.sql, seed.php
*.php (root)      index, movies, games, top10, new, search, details,
                  login, register, logout, profile, edit_profile, collection, reviews
```

## 4. Database design

- `users` — auth + profile (avatar, bio)
- `genres` — shared master list; used by movies, games, or both
- `movies` / `games` — external rating fields kept separate from personal ratings
- `movie_genres` / `game_genres` — many-to-many junctions (normalized, no comma-separated genre strings)
- `collections` — a user's library; **completely separate** from reviews
- `reviews` — holds both the user's personal 0.5–5.0 rating *and* review text; a user can only edit/delete their own row (enforced by `WHERE user_id = ?` on every write)

## 5. How the major features work

- **Featured carousel**: `get_featured_candidates()` pulls a random mix of
  highly-rated movies and games (`ORDER BY RAND()` from rows with
  `external_rating >= 4.0`), so it's never the same item twice in a row.
  `featured.js` auto-rotates every 12s with prev/next buttons and dot indicators.
- **Movies/Games filter panel**: a slide-in panel (CSS `transform: translateX`)
  with genre checkboxes and a dual-range rating slider. `filters.js` submits
  the form via `fetch()` to `movies.php`/`games.php`, which detect the AJAX
  request and return just the results grid HTML — the URL is updated with
  `history.pushState` so filters are shareable/refreshable.
- **Filtering SQL**: `filter_items()` in `includes/functions.php` builds a
  parameterized query with `JOIN ... WHERE external_rating BETWEEN ? AND ?`
  and `genre.name IN (?,?,...)` — always prepared statements, never raw
  concatenation of user input.
- **Search**: `search_all()` uses `LIKE` prepared statements against movie/game
  titles and genre names.
- **Top 10 / New**: straightforward `ORDER BY external_rating DESC LIMIT 10`
  and `ORDER BY release_date DESC` queries.
- **Collections**: AJAX add/remove via `api/collection_action.php`, using
  `INSERT IGNORE` / `UNIQUE(user_id, item_type, item_id)` to prevent duplicates.
  Never depends on a review existing.
- **Reviews**: full CRUD on `details.php` (create/update via upsert on a
  unique key, delete restricted to the owning `user_id`). Independent of collections.
- **Profile**: avatar upload validated by extension + real MIME type (via
  `finfo`) + `getimagesize()`, max 2MB, random-suffixed safe filename, old
  avatar file deleted on replace. Bio is escaped on output to prevent XSS.
- **Auth/security**: the current user is always read from
  `$_SESSION['user_id']` (see `includes/auth.php`) — never trusted from a
  submitted field. Protected pages call `require_login()`. Passwords hashed
  with `password_hash()`/`password_verify()`.

## 6. Using real movie/game posters (optional)

By default, `seed.php` fills `poster_url`/`cover_url`/`backdrop_url` with
placeholder images from `picsum.photos` (seeded by title, so it's consistent
but not real box art). To use real images instead:

1. Save an image for a movie into `assets/img/posters/`, named as its slug
   (lowercase, spaces and punctuation replaced with hyphens) — e.g. "The Dark
   Knight" → `assets/img/posters/the-dark-knight.jpg`.
2. Save an image for a game into `assets/img/covers/` the same way — e.g.
   "Elden Ring" → `assets/img/covers/elden-ring.jpg`.
3. Supported extensions: `.jpg`, `.jpeg`, `.png`, `.webp`.
4. Run (or re-run) `php database/seed.php`. Any title with a matching local
   file automatically uses that image instead of a placeholder — no code
   changes needed, and it's safe to run this repeatedly as you add more files.
   Re-running it never duplicates data; it just upgrades a title's image if a
   matching file has been added since the last run.
5. A title with no matching local file just keeps its placeholder — that's
   fine, nothing else about the app changes either way.

## 7. Notes on seed data / images

- Titles, years, genres, and short descriptions are real, recognizable
  movies/games (no "Movie 1 / Movie 2" filler), written in original wording.
- External ratings/rating counts are generated deterministically per title
  (a hash of the title, not true randomness) so the same title always gets
  the same rating and the dataset has realistic variation without needing
  a live API key.
- Poster/backdrop/cover images use whatever you've manually saved into
  `assets/img/posters/`/`covers/` (see section 6); anything without a
  matching file falls back to a `picsum.photos` placeholder image seeded
  by title.
- Ratings themselves (the number of stars) stay deterministic/synthetic either
  way — real or placeholder images don't change the rating math.

## 8. Quick test checklist

1. Run the seed script and check its genre-verification output (all ≥ 5).
2. Visit `/` — Featured should rotate; Top 10 / New sections populate.
3. Click **Movies** / **Games** in the sidebar — filter panel slides in;
   check a genre + drag the rating slider (labels update live) → Apply.
4. Register an account, then: add something to your collection (no review
   needed), write a review on a different item (no collection needed),
   confirm they're independent on **My Collection** / **My Reviews**.
5. Edit and delete your own review; confirm you cannot see an edit/delete
   button on someone else's review.
6. Edit your profile: upload an avatar (try a non-image file — it should be
   rejected), change your bio, save.
7. Log out and confirm Add-to-Collection / review actions are blocked with a
   "please log in" message, while browsing/search/details still work.
8. Shrink the browser to mobile width — hamburger menu, full-width filter
   panel, and card grid should all still work with no horizontal scroll.
