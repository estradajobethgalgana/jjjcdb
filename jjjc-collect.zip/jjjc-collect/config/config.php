<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'moviegame_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'JJJC.Collect');
define('APP_LOGO', 'assets/img/logo.png');
define('BASE_URL', '');

define('AVATAR_UPLOAD_DIR', __DIR__ . '/../assets/uploads/avatars/');
define('AVATAR_UPLOAD_URL', 'assets/uploads/avatars/');
define('AVATAR_MAX_SIZE', 2 * 1024 * 1024);
define('AVATAR_ALLOWED_EXT', ['jpg', 'jpeg', 'png', 'webp']);
define('AVATAR_ALLOWED_MIME', ['image/jpeg', 'image/png', 'image/webp']);

define('RATING_MIN', 0.0);
define('RATING_MAX', 5.0);
define('RATING_STEP', 0.5);

error_reporting(E_ALL);
ini_set('display_errors', '1');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

date_default_timezone_set('UTC');
