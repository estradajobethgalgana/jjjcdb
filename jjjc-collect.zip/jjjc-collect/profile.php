<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login();
$me = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_review') {
    $reviewId = (int)($_POST['review_id'] ?? 0);
    if ($reviewId > 0 && delete_review($me['id'], $reviewId)) {
        flash_set('flash_success', 'Review deleted.');
    } else {
        flash_set('flash_error', 'Could not delete that review.');
    }
    redirect('profile.php');
}

$collection = get_user_collection($me['id']);
$myReviews = get_user_reviews($me['id']);

$pageTitle = 'Profile';
$extraStyles = ['assets/css/bio-profile.css'];
require_once __DIR__ . '/includes/header.php';
?>

<div class="bio-page-wrap">
  <a href="index.php" class="btn-back">&larr; BACK</a>

  <div class="profile-section">
    <div class="profile-pic">
      <img src="<?= e($me['avatar'] ? AVATAR_UPLOAD_URL . $me['avatar'] : 'assets/img/default-avatar.svg') ?>" alt="Profile Picture">
    </div>
    <div class="profile-info">
      <h1><?= e(strtoupper($me['username'])) ?></h1>
      <p class="profile-email"><?= e($me['email']) ?></p>
      <a href="edit_profile.php" class="btn-edit-profile">EDIT PROF</a>
    </div>
  </div>

  <div class="bio-section">
    <h2>Bio</h2>
    <?php if (!empty($me['bio'])): ?>
      <div class="bio-display"><?= nl2br(e($me['bio'])) ?></div>
    <?php else: ?>
      <div class="bio-display muted">No bio yet. Click Edit Profile to add one.</div>
    <?php endif; ?>
  </div>

  <div class="collection-section">
    <h2>My Collection</h2>
    <?php if (empty($collection)): ?>
      <p class="empty-state">Your collection is empty. Add movies or games from any details page.</p>
    <?php else: ?>
      <div class="collection-grid">
        <?php foreach ($collection as $item): ?>
          <a class="collection-item" href="details.php?type=<?= e($item['item_type']) ?>&id=<?= (int)$item['id'] ?>" title="<?= e($item['title']) ?>">
            <img src="<?= e($item['image'] ?: placeholder_image($item['item_type'] . $item['id'], 300, 450)) ?>" alt="<?= e($item['title']) ?>">
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <div class="review-section">
    <h2>My Reviews</h2>
    <?php if (empty($myReviews)): ?>
      <p class="empty-state">You haven't written any reviews yet.</p>
    <?php else: ?>
      <?php foreach ($myReviews as $r): ?>
        <?php $item = $r['item']; if (!$item) continue; ?>
        <div class="bio-review-item">
          <div class="review-avatar">
            <img src="<?= e($item['image'] ?: placeholder_image($r['item_type'] . $r['item_id'], 160, 240)) ?>" alt="<?= e($item['title']) ?>">
          </div>
          <div class="review-content">
            <a class="review-name" href="details.php?type=<?= e($r['item_type']) ?>&id=<?= (int)$r['item_id'] ?>"><?= e($item['title']) ?></a>
            <div class="review-stars"><?= render_stars((float)$r['rating']) ?></div>
            <div class="review-comment-display"><?= nl2br(e($r['review_text'])) ?></div>
            <div class="bio-review-actions">
              <a class="btn-edit" href="details.php?type=<?= e($r['item_type']) ?>&id=<?= (int)$r['item_id'] ?>#reviews">EDIT</a>
              <form method="post" action="profile.php" onsubmit="return confirm('Delete this review?');" class="inline-form">
                <input type="hidden" name="action" value="delete_review">
                <input type="hidden" name="review_id" value="<?= (int)$r['id'] ?>">
                <button type="submit" class="btn-delete">DELETE</button>
              </form>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
