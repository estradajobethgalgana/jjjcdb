<?php if (empty($items)): ?>
  <p class="empty-state"><?php echo e($emptyMessage); ?></p>
<?php else: ?>
  <div class="item-grid">
    <?php foreach ($items as $item): ?>
      <?php include __DIR__ . '/item_card.php'; ?>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
