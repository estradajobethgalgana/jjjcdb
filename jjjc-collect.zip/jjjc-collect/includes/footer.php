    </main>
  </div>
</div>

<div class="toast-container" id="toastContainer" aria-live="polite"></div>

<script src="assets/js/main.js"></script>
<?php if (!empty($extraScripts)) foreach ($extraScripts as $src): ?>
<script src="<?= e($src) ?>"></script>
<?php endforeach; ?>
</body>
</html>
