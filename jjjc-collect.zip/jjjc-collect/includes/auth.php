<?php

require_once __DIR__ . '/../config/database.php';

function is_logged_in(): bool
{
    return isset($_SESSION['user_id']);
}

function current_user_id(): ?int
{
    return $_SESSION['user_id'] ?? null;
}

function current_user(): ?array
{
    static $cached = null;
    static $fetched = false;

    if ($fetched) {
        return $cached;
    }
    $fetched = true;

    if (!is_logged_in()) {
        return null;
    }

    $db = Database::getConnection();
    $stmt = $db->prepare('SELECT id, username, first_name, last_name, date_of_birth, email, avatar, bio, created_at FROM users WHERE id = ?');
    $stmt->execute([current_user_id()]);
    $cached = $stmt->fetch() ?: null;

    return $cached;
}

function require_login(string $redirectTo = 'login.php'): void
{
    if (!is_logged_in()) {
        $_SESSION['flash_error'] = 'Please log in to continue.';
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? null;
        header('Location: ' . $redirectTo);
        exit;
    }
}

function login_user(int $userId): void
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = $userId;
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

function hash_password(string $plain): string
{
    return password_hash($plain, PASSWORD_DEFAULT);
}

function verify_password(string $plain, string $hash): bool
{
    return password_verify($plain, $hash);
}

function generate_unique_username(string $email): string
{
    $base = strtolower(explode('@', $email)[0]);
    $base = preg_replace('/[^a-z0-9_]/', '', $base);
    if (strlen($base) < 3) {
        $base = $base . '000';
    }
    $base = substr($base, 0, 25);
    return $base . rand(1000, 9999);
}
