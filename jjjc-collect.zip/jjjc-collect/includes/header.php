<?php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/functions.php';

$pageTitle = $pageTitle ?? APP_NAME;
$activeNav = $activeNav ?? '';
$me = current_user();
$successMsg = flash_get('flash_success');
$errorMsg   = flash_get('flash_error');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> · <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="assets/css/style.css">
<?php if (!empty($extraStyles)) foreach ($extraStyles as $href): ?>
<link rel="stylesheet" href="<?= e($href) ?>">
<?php endforeach; ?>
<link rel="icon" href="<?= e(APP_LOGO) ?>" type="image/png">
</head>
<body>

<button class="mobile-nav-toggle" id="mobileNavToggle" aria-label="Toggle navigation" aria-expanded="false" aria-controls="sidebar">
  <span></span><span></span><span></span>
</button>

<div class="app-shell">

  <nav class="sidebar" id="sidebar" aria-label="Main navigation">
    <a href="index.php" class="sidebar-logo">
      <img src="<?= e(APP_LOGO) ?>" alt="<?= e(APP_NAME) ?> logo" class="logo-mark-img">
      <span class="logo-text"><?= e(APP_NAME) ?></span>
    </a>
    <ul class="sidebar-nav">
      <li>
        <a href="index.php" class="nav-link <?= $activeNav === 'home' ? 'active' : '' ?>">
          <span class="nav-icon" aria-hidden="true">&#8962;</span><span>Home</span>
        </a>
      </li>
      <li>
        <a href="movies.php" class="nav-link nav-movies <?= $activeNav === 'movies' ? 'active' : '' ?>" data-filter-page="movies.php">
          <span class="nav-icon" aria-hidden="true">&#127916;</span><span>Movies</span>
        </a>
      </li>
      <li>
        <a href="games.php" class="nav-link nav-games <?= $activeNav === 'games' ? 'active' : '' ?>" data-filter-page="games.php">
          <span class="nav-icon" aria-hidden="true">&#127918;</span><span>Games</span>
        </a>
      </li>
      <li>
        <a href="top10.php" class="nav-link <?= $activeNav === 'top10' ? 'active' : '' ?>">
          <span class="nav-icon" aria-hidden="true">&#128293;</span><span>Top 10</span>
        </a>
      </li>
      <li>
        <a href="new.php" class="nav-link <?= $activeNav === 'new' ? 'active' : '' ?>">
          <span class="nav-icon" aria-hidden="true">&#10024;</span><span>New</span>
        </a>
      </li>
    </ul>
    <div class="sidebar-footer">
      <span>&copy; <?= date('Y') ?> <?= e(APP_NAME) ?></span>
    </div>
  </nav>

  <div class="app-main">

    <header class="topbar">
      <form class="search-form" action="search.php" method="get" role="search">
        <input type="search" name="q" id="searchInput" placeholder="Search movies, games, genres..."
               value="<?= e($_GET['q'] ?? '') ?>" aria-label="Search movies, games, genres">
        <button type="submit" class="search-btn" aria-label="Search">&#128269;</button>
      </form>

      <div class="profile-area">
        <?php if ($me): ?>
          <button class="profile-btn" id="profileBtn" aria-haspopup="true" aria-expanded="false" aria-controls="profileDropdown">
            <img src="<?= e($me['avatar'] ? AVATAR_UPLOAD_URL . $me['avatar'] : 'assets/img/default-avatar.svg') ?>"
                 alt="" class="avatar-sm">
            <span class="profile-name"><?= e($me['username']) ?></span>
            <span class="caret" aria-hidden="true">&#9662;</span>
          </button>
          <div class="profile-dropdown" id="profileDropdown" role="menu">
            <div class="dropdown-head">
              <img src="<?= e($me['avatar'] ? AVATAR_UPLOAD_URL . $me['avatar'] : 'assets/img/default-avatar.svg') ?>" alt="" class="avatar-sm">
              <div>
                <strong><?= e($me['username']) ?></strong>
              </div>
            </div>
            <a href="profile.php" role="menuitem">View Profile</a>
            <a href="edit_profile.php" role="menuitem">Edit Profile</a>
            <div class="dropdown-divider"></div>
            <a href="logout.php" role="menuitem" class="danger">Logout</a>
          </div>
        <?php else: ?>
          <a href="login.php" class="btn btn-outline">Log In</a>
          <a href="login.php?view=register" class="btn btn-primary">Sign Up</a>
        <?php endif; ?>
      </div>
    </header>

    <?php if ($successMsg): ?>
      <div class="flash flash-success" role="status"><?= e($successMsg) ?></div>
    <?php endif; ?>
    <?php if ($errorMsg): ?>
      <div class="flash flash-error" role="alert"><?= e($errorMsg) ?></div>
    <?php endif; ?>

    <main class="main-content">
