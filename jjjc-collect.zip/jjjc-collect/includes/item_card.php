<?php
$type    = $item['item_type'];
$id      = (int)$item['id'];
$title   = $item['title'];
$year    = $item['release_year'] ?? '';
$rating  = $item['external_rating'] ?? 0;
$source  = $item['external_rating_source'] ?? '';
$image   = $item['image'] ?: placeholder_image($type . '-' . $id, 400, 600);
$genres  = $item['genres'] ?? get_genres_for_item($type, $id);

$genreNames = [];
foreach (array_slice($genres, 0, 2) as $g) {
    $genreNames[] = $g['name'];
}

$currentUserId = current_user_id();
if ($currentUserId) {
    $inCollection = is_in_collection($currentUserId, $type, $id);
} else {
    $inCollection = false;
}
?>
<article class="item-card" data-type="<?php echo e($type); ?>" data-id="<?php echo $id; ?>">
  <a href="details.php?type=<?php echo e($type); ?>&id=<?php echo $id; ?>" class="card-media-link" aria-label="View details for <?php echo e($title); ?>">
    <div class="card-media">
      <img src="<?php echo e($image); ?>" alt="<?php echo e($title); ?> <?php echo $type === 'movie' ? 'poster' : 'cover'; ?>" loading="lazy">
      <div class="card-overlay">
        <span class="btn btn-sm btn-primary">View Details</span>
      </div>
    </div>
  </a>
  <div class="card-body">
    <h3 class="card-title"><a href="details.php?type=<?php echo e($type); ?>&id=<?php echo $id; ?>"><?php echo e($title); ?></a></h3>
    <p class="card-meta">
      <?php echo e((string)$year); ?>
      <?php if (!empty($genreNames)): ?>
        &bull; <?php echo e(implode(' &bull; ', $genreNames)); ?>
      <?php endif; ?>
    </p>
    <p class="card-rating">&#9733; <?php echo number_format((float)$rating, 1); ?>/5 <span class="rating-source"><?php echo e($source); ?></span></p>
    <?php if ($inCollection): ?>
      <button type="button" class="btn btn-sm collection-btn in-collection" data-type="<?php echo e($type); ?>" data-id="<?php echo $id; ?>" data-in="1">
        &#10003; In Collection
      </button>
    <?php else: ?>
      <button type="button" class="btn btn-sm collection-btn" data-type="<?php echo e($type); ?>" data-id="<?php echo $id; ?>" data-in="0">
        + Collection
      </button>
    <?php endif; ?>
  </div>
</article>
