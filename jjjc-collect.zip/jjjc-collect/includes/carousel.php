<?php if (empty($items)): ?>
  <p class="empty-state"><?php echo e($emptyMessage); ?></p>
<?php else: ?>
  <div class="carousel-wrap" id="<?php echo e($carouselId); ?>">
    <button type="button" class="carousel-arrow carousel-prev" aria-label="Previous">&#10094;</button>
    <div class="carousel-viewport">
      <div class="carousel-track">
        <?php foreach ($items as $item): ?>
          <div class="carousel-item">
            <?php include __DIR__ . '/item_card.php'; ?>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    <button type="button" class="carousel-arrow carousel-next" aria-label="Next">&#10095;</button>
    <div class="carousel-dots"></div>
  </div>
<?php endif; ?>
