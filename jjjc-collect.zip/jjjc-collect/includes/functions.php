<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/auth.php';

function e(?string $str): string
{
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function clean_str(?string $str): string
{
    return trim($str ?? '');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function flash_set(string $key, string $message): void
{
    $_SESSION[$key] = $message;
}

function flash_get(string $key): ?string
{
    if (!empty($_SESSION[$key])) {
        $msg = $_SESSION[$key];
        unset($_SESSION[$key]);
        return $msg;
    }
    return null;
}

function json_response(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function is_ajax(): bool
{
    return (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])
        && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');
}

function placeholder_image(string $seed, int $w, int $h): string
{
    $slug = rawurlencode($seed);
    return "https://picsum.photos/seed/{$slug}/{$w}/{$h}";
}

function clamp_rating(float $val): float
{
    $val = max(RATING_MIN, min(RATING_MAX, $val));

    return round($val / RATING_STEP) * RATING_STEP;
}

function render_stars(?float $rating, int $max = 5): string
{
    $rating = $rating ?? 0;
    $html = '<span class="stars" aria-label="' . e((string)$rating) . ' out of ' . $max . ' stars">';
    for ($i = 1; $i <= $max; $i++) {
        if ($rating >= $i) {
            $html .= '<i class="star full">&#9733;</i>';
        } elseif ($rating >= $i - 0.5) {
            $html .= '<i class="star half">&#9733;</i>';
        } else {
            $html .= '<i class="star empty">&#9734;</i>';
        }
    }
    $html .= '</span>';
    return $html;
}

function get_genres_for_type(string $type): array
{
    $db = Database::getConnection();
    $table = $type === 'movie' ? 'movie_genres' : 'game_genres';
    $col   = $type === 'movie' ? 'movie_id' : 'game_id';
    $stmt = $db->query("
        SELECT DISTINCT g.id, g.name
        FROM genres g
        JOIN {$table} j ON j.genre_id = g.id
        ORDER BY g.name ASC
    ");
    return $stmt->fetchAll();
}

function get_genres_for_item(string $type, int $id): array
{
    $db = Database::getConnection();
    $table = $type === 'movie' ? 'movie_genres' : 'game_genres';
    $col   = $type === 'movie' ? 'movie_id' : 'game_id';
    $stmt = $db->prepare("
        SELECT g.id, g.name
        FROM genres g
        JOIN {$table} j ON j.genre_id = g.id
        WHERE j.{$col} = ?
        ORDER BY g.name ASC
    ");
    $stmt->execute([$id]);
    return $stmt->fetchAll();
}

function valid_item_type(string $type): bool
{
    return in_array($type, ['movie', 'game'], true);
}

function get_item(string $type, int $id): ?array
{
    if (!valid_item_type($type)) return null;
    $db = Database::getConnection();
    $table = $type === 'movie' ? 'movies' : 'games';
    $stmt = $db->prepare("SELECT * FROM {$table} WHERE id = ?");
    $stmt->execute([$id]);
    $item = $stmt->fetch();
    if ($item) {
        $item['item_type'] = $type;
        $item['image']     = $type === 'movie' ? $item['poster_url'] : $item['cover_url'];
        $item['genres']    = get_genres_for_item($type, $id);
    }
    return $item ?: null;
}

function filter_items(string $type, array $genreNames, float $minRating, float $maxRating, ?string $search = null, string $orderBy = 'rating', int $limit = 60): array
{
    if (!valid_item_type($type)) return [];
    $db = Database::getConnection();
    $table      = $type === 'movie' ? 'movies' : 'games';
    $joinTable  = $type === 'movie' ? 'movie_genres' : 'game_genres';
    $joinCol    = $type === 'movie' ? 'movie_id' : 'game_id';

    $params = [];
    $sql = "SELECT DISTINCT t.* FROM {$table} t";

    if (!empty($genreNames)) {
        $sql .= " JOIN {$joinTable} jg ON jg.{$joinCol} = t.id JOIN genres g ON g.id = jg.genre_id";
    }

    $where = ['t.external_rating BETWEEN ? AND ?'];
    $params[] = $minRating;
    $params[] = $maxRating;

    if (!empty($genreNames)) {
        $placeholders = implode(',', array_fill(0, count($genreNames), '?'));
        $where[] = "g.name IN ({$placeholders})";
        foreach ($genreNames as $g) { $params[] = $g; }
    }

    if ($search !== null && $search !== '') {
        $where[] = 't.title LIKE ?';
        $params[] = '%' . $search . '%';
    }

    $sql .= ' WHERE ' . implode(' AND ', $where);

    switch ($orderBy) {
        case 'newest':
            $sql .= ' ORDER BY t.release_date DESC, t.id DESC';
            break;
        case 'title':
            $sql .= ' ORDER BY t.title ASC';
            break;
        case 'rating':
        default:
            $sql .= ' ORDER BY t.external_rating DESC, t.external_rating_count DESC';
    }

    $sql .= ' LIMIT ' . (int)$limit;

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['item_type'] = $type;
        $row['image'] = $type === 'movie' ? $row['poster_url'] : $row['cover_url'];
    }
    return $rows;
}

function search_all(string $term, int $limitEach = 20): array
{
    $db = Database::getConnection();
    $like = '%' . $term . '%';

    $movieStmt = $db->prepare("
        SELECT DISTINCT m.* FROM movies m
        LEFT JOIN movie_genres mg ON mg.movie_id = m.id
        LEFT JOIN genres g ON g.id = mg.genre_id
        WHERE m.title LIKE ? OR g.name LIKE ?
        ORDER BY m.external_rating DESC
        LIMIT {$limitEach}
    ");
    $movieStmt->execute([$like, $like]);
    $movies = $movieStmt->fetchAll();
    foreach ($movies as &$m) { $m['item_type'] = 'movie'; $m['image'] = $m['poster_url']; }

    $gameStmt = $db->prepare("
        SELECT DISTINCT ga.* FROM games ga
        LEFT JOIN game_genres gg ON gg.game_id = ga.id
        LEFT JOIN genres g ON g.id = gg.genre_id
        WHERE ga.title LIKE ? OR g.name LIKE ?
        ORDER BY ga.external_rating DESC
        LIMIT {$limitEach}
    ");
    $gameStmt->execute([$like, $like]);
    $games = $gameStmt->fetchAll();
    foreach ($games as &$g) { $g['item_type'] = 'game'; $g['image'] = $g['cover_url']; }

    return ['movies' => $movies, 'games' => $games];
}

function top10(string $type): array
{
    if (!valid_item_type($type)) return [];
    $db = Database::getConnection();
    $table = $type === 'movie' ? 'movies' : 'games';
    $stmt = $db->query("SELECT * FROM {$table} ORDER BY external_rating DESC, external_rating_count DESC LIMIT 10");
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) { $r['item_type'] = $type; $r['image'] = $type === 'movie' ? $r['poster_url'] : $r['cover_url']; }
    return $rows;
}

function newest(string $type, int $limit = 12): array
{
    if (!valid_item_type($type)) return [];
    $db = Database::getConnection();
    $table = $type === 'movie' ? 'movies' : 'games';
    $stmt = $db->prepare("SELECT * FROM {$table} ORDER BY release_date DESC, id DESC LIMIT ?");
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) { $r['item_type'] = $type; $r['image'] = $type === 'movie' ? $r['poster_url'] : $r['cover_url']; }
    return $rows;
}

function get_featured_candidates(int $count = 6): array
{
    $db = Database::getConnection();
    $half = (int)ceil($count / 2);

    $movieStmt = $db->prepare("
        SELECT * FROM movies WHERE external_rating >= 4.0
        ORDER BY RAND() LIMIT ?
    ");
    $movieStmt->bindValue(1, $half, PDO::PARAM_INT);
    $movieStmt->execute();
    $movies = $movieStmt->fetchAll();
    foreach ($movies as &$m) { $m['item_type'] = 'movie'; $m['image'] = $m['backdrop_url']; }

    $gameStmt = $db->prepare("
        SELECT * FROM games WHERE external_rating >= 4.0
        ORDER BY RAND() LIMIT ?
    ");
    $gameStmt->bindValue(1, $count - $half, PDO::PARAM_INT);
    $gameStmt->execute();
    $games = $gameStmt->fetchAll();
    foreach ($games as &$g) { $g['item_type'] = 'game'; $g['image'] = $g['backdrop_url']; }

    $combined = array_merge($movies, $games);
    shuffle($combined);
    foreach ($combined as &$item) {
        $item['genres'] = get_genres_for_item($item['item_type'], $item['id']);
    }
    return $combined;
}

function is_in_collection(int $userId, string $type, int $itemId): bool
{
    $db = Database::getConnection();
    $stmt = $db->prepare('SELECT 1 FROM collections WHERE user_id = ? AND item_type = ? AND item_id = ?');
    $stmt->execute([$userId, $type, $itemId]);
    return (bool)$stmt->fetchColumn();
}

function add_to_collection(int $userId, string $type, int $itemId): bool
{
    if (!valid_item_type($type)) return false;
    $db = Database::getConnection();
    $stmt = $db->prepare('INSERT IGNORE INTO collections (user_id, item_type, item_id) VALUES (?, ?, ?)');
    return $stmt->execute([$userId, $type, $itemId]);
}

function remove_from_collection(int $userId, string $type, int $itemId): bool
{
    $db = Database::getConnection();
    $stmt = $db->prepare('DELETE FROM collections WHERE user_id = ? AND item_type = ? AND item_id = ?');
    return $stmt->execute([$userId, $type, $itemId]);
}

function get_user_collection(int $userId, ?string $type = null): array
{
    $db = Database::getConnection();
    $params = [$userId];
    $typeFilter = '';
    if ($type !== null && valid_item_type($type)) {
        $typeFilter = ' AND c.item_type = ?';
        $params[] = $type;
    }
    $stmt = $db->prepare("
        SELECT c.item_type, c.item_id, c.created_at
        FROM collections c
        WHERE c.user_id = ?{$typeFilter}
        ORDER BY c.created_at DESC
    ");
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    $result = [];
    foreach ($rows as $row) {
        $item = get_item($row['item_type'], $row['item_id']);
        if ($item) {
            $item['collected_at'] = $row['created_at'];
            $result[] = $item;
        }
    }
    return $result;
}

function count_collection(int $userId): array
{
    $db = Database::getConnection();
    $stmt = $db->prepare("SELECT item_type, COUNT(*) c FROM collections WHERE user_id = ? GROUP BY item_type");
    $stmt->execute([$userId]);
    $counts = ['movie' => 0, 'game' => 0];
    foreach ($stmt->fetchAll() as $row) {
        $counts[$row['item_type']] = (int)$row['c'];
    }
    return $counts;
}

function get_user_review(int $userId, string $type, int $itemId): ?array
{
    $db = Database::getConnection();
    $stmt = $db->prepare('SELECT * FROM reviews WHERE user_id = ? AND item_type = ? AND item_id = ?');
    $stmt->execute([$userId, $type, $itemId]);
    return $stmt->fetch() ?: null;
}

function get_reviews_for_item(string $type, int $itemId): array
{
    $db = Database::getConnection();
    $stmt = $db->prepare("
        SELECT r.*, u.username, u.avatar
        FROM reviews r
        JOIN users u ON u.id = r.user_id
        WHERE r.item_type = ? AND r.item_id = ?
        ORDER BY r.created_at DESC
    ");
    $stmt->execute([$type, $itemId]);
    return $stmt->fetchAll();
}

function get_user_reviews(int $userId): array
{
    $db = Database::getConnection();
    $stmt = $db->prepare('SELECT * FROM reviews WHERE user_id = ? ORDER BY created_at DESC');
    $stmt->execute([$userId]);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['item'] = get_item($row['item_type'], $row['item_id']);
    }
    return $rows;
}

function upsert_review(int $userId, string $type, int $itemId, float $rating, string $text): bool
{
    if (!valid_item_type($type)) return false;
    $db = Database::getConnection();
    $stmt = $db->prepare("
        INSERT INTO reviews (user_id, item_type, item_id, rating, review_text)
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE rating = VALUES(rating), review_text = VALUES(review_text), updated_at = NOW()
    ");
    return $stmt->execute([$userId, $type, $itemId, $rating, $text]);
}

function delete_review(int $userId, int $reviewId): bool
{
    $db = Database::getConnection();

    $stmt = $db->prepare('DELETE FROM reviews WHERE id = ? AND user_id = ?');
    return $stmt->execute([$reviewId, $userId]);
}

function get_average_user_rating(string $type, int $itemId): ?float
{
    $db = Database::getConnection();
    $stmt = $db->prepare('SELECT AVG(rating) avg_r, COUNT(*) c FROM reviews WHERE item_type = ? AND item_id = ?');
    $stmt->execute([$type, $itemId]);
    $row = $stmt->fetch();
    if (!$row || (int)$row['c'] === 0) return null;
    return round((float)$row['avg_r'], 1);
}

function count_user_reviews(int $userId): int
{
    $db = Database::getConnection();
    $stmt = $db->prepare('SELECT COUNT(*) FROM reviews WHERE user_id = ?');
    $stmt->execute([$userId]);
    return (int)$stmt->fetchColumn();
}

function avg_rating_given_by_user(int $userId): ?float
{
    $db = Database::getConnection();
    $stmt = $db->prepare('SELECT AVG(rating) FROM reviews WHERE user_id = ?');
    $stmt->execute([$userId]);
    $val = $stmt->fetchColumn();
    return $val !== null ? round((float)$val, 1) : null;
}
