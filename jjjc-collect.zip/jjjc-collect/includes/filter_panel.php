<?php

$filterLabel = $filterType === 'movie' ? 'Movies' : 'Games';
?>
<div class="filter-panel" id="filterPanel" data-type="<?= e($filterType) ?>" aria-hidden="true" aria-label="<?= e($filterLabel) ?> filters">
  <div class="filter-panel-header">
    <h2><?= e(strtoupper($filterLabel)) ?></h2>
    <button type="button" class="filter-close" id="filterClose" aria-label="Close filters">&#10005;</button>
  </div>

  <form id="filterForm" class="filter-form">
    <fieldset>
      <legend>Genres</legend>
      <div class="genre-checklist">
        <?php foreach ($filterGenres as $g): ?>
          <label class="genre-check">
            <input type="checkbox" name="genre[]" value="<?= e($g['name']) ?>"
              <?= in_array($g['name'], $selectedGenres, true) ? 'checked' : '' ?>>
            <span><?= e($g['name']) ?></span>
          </label>
        <?php endforeach; ?>
      </div>
    </fieldset>

    <fieldset class="rating-fieldset">
      <legend>Rating</legend>
      <div class="dual-slider" data-min="<?= RATING_MIN ?>" data-max="<?= RATING_MAX ?>" data-step="<?= RATING_STEP ?>">
        <label for="minRating" class="sr-only">Minimum rating</label>
        <input type="range" id="minRating" min="<?= RATING_MIN ?>" max="<?= RATING_MAX ?>" step="<?= RATING_STEP ?>" value="<?= e((string)$minRating) ?>">
        <label for="maxRating" class="sr-only">Maximum rating</label>
        <input type="range" id="maxRating" min="<?= RATING_MIN ?>" max="<?= RATING_MAX ?>" step="<?= RATING_STEP ?>" value="<?= e((string)$maxRating) ?>">
        <div class="slider-track"><div class="slider-range" id="sliderRange"></div></div>
      </div>
      <div class="rating-readout">
        <span>Minimum: <strong id="minRatingLabel">&#9733; <?= number_format($minRating, 1) ?></strong></span>
        <span>Maximum: <strong id="maxRatingLabel">&#9733; <?= number_format($maxRating, 1) ?></strong></span>
      </div>
    </fieldset>

    <div class="filter-actions">
      <button type="submit" class="btn btn-primary" id="applyFilters">Apply Filters</button>
      <button type="button" class="btn btn-outline" id="resetFilters">Reset</button>
    </div>
  </form>
</div>
<div class="filter-backdrop" id="filterBackdrop"></div>
