<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

if (is_logged_in()) {
    redirect('index.php');
}

$loginErrors = [];
$registerErrors = [];
$activeView = ($_GET['view'] ?? '') === 'register' ? 'register' : 'login';
$loginEmail = '';
$regFirstName = '';
$regLastName = '';
$regDob = '';
$regEmail = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formType = $_POST['form_type'] ?? '';

    if ($formType === 'login') {
        $activeView = 'login';
        $loginEmail = clean_str($_POST['email'] ?? '');
        $password = (string)($_POST['password'] ?? '');

        if ($loginEmail === '' || $password === '') {
            $loginErrors[] = 'Please enter your email and password.';
        } else {
            $db = Database::getConnection();
            $stmt = $db->prepare('SELECT id, password_hash FROM users WHERE email = ? LIMIT 1');
            $stmt->execute([$loginEmail]);
            $user = $stmt->fetch();

            if ($user && verify_password($password, $user['password_hash'])) {
                login_user((int)$user['id']);
                $redirectTo = $_SESSION['redirect_after_login'] ?? 'index.php';
                unset($_SESSION['redirect_after_login']);
                flash_set('flash_success', 'Welcome back!');
                redirect($redirectTo ?: 'index.php');
            } else {
                $loginErrors[] = 'Incorrect email or password.';
            }
        }
    } elseif ($formType === 'register') {
        $activeView = 'register';
        $regFirstName = clean_str($_POST['first_name'] ?? '');
        $regLastName  = clean_str($_POST['last_name'] ?? '');
        $regDob       = clean_str($_POST['date_of_birth'] ?? '');
        $regEmail     = clean_str($_POST['email'] ?? '');
        $regPassword  = (string)($_POST['password'] ?? '');

        if ($regFirstName === '' || $regLastName === '') {
            $registerErrors[] = 'Please enter your first and last name.';
        }
        if (!filter_var($regEmail, FILTER_VALIDATE_EMAIL)) {
            $registerErrors[] = 'Please enter a valid email address.';
        }
        $dobTimestamp = strtotime($regDob);
        if ($regDob === '' || $dobTimestamp === false || $dobTimestamp > time()) {
            $registerErrors[] = 'Please enter a valid date of birth.';
        }
        if (strlen($regPassword) < 8) {
            $registerErrors[] = 'Password must be at least 8 characters.';
        }

        if (empty($registerErrors)) {
            $db = Database::getConnection();
            $stmt = $db->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
            $stmt->execute([$regEmail]);
            if ($stmt->fetch()) {
                $registerErrors[] = 'That email is already registered.';
            } else {
                $username = generate_unique_username($regEmail);
                $insert = $db->prepare('
                    INSERT INTO users (username, first_name, last_name, date_of_birth, email, password_hash)
                    VALUES (?, ?, ?, ?, ?, ?)
                ');
                $insert->execute([
                    $username, $regFirstName, $regLastName, date('Y-m-d', $dobTimestamp),
                    $regEmail, hash_password($regPassword),
                ]);
                login_user((int)$db->lastInsertId());
                flash_set('flash_success', 'Welcome to ' . APP_NAME . '!');
                redirect('index.php');
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login / Register &middot; <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="assets/css/auth.css">
<link rel="icon" href="<?= e(APP_LOGO) ?>" type="image/png">
</head>
<body>

<div class="stage<?= $activeView === 'register' ? ' register' : '' ?>" id="stage">

  <section class="panel-brand">
    <div class="logo-wrap">
      <div class="logo-circle">
        <img src="<?= e(APP_LOGO) ?>" alt="<?= e(APP_NAME) ?> logo">
      </div>
    </div>

    <div class="get-started">
      <h1>Get<br>Started</h1>
      <p>Create your account and start collecting.</p>
    </div>

    <div class="brand-footer">&copy; <?= date('Y') ?> <?= e(APP_NAME) ?></div>
  </section>

  <section class="panel-form">
    <div class="form-stage">

      <form class="auth-card" id="loginCard" method="post" action="login.php" novalidate>
        <h2>Login</h2>
        <input type="hidden" name="form_type" value="login">

        <?php foreach ($loginErrors as $err): ?>
          <p class="field-error show"><?= e($err) ?></p>
        <?php endforeach; ?>

        <div class="field">
          <label for="loginEmail">Email</label>
          <div class="input-wrap">
            <input type="email" id="loginEmail" name="email" placeholder="Enter your email" autocomplete="email" value="<?= e($loginEmail) ?>">
          </div>
          <p class="field-error" id="loginEmailError">Please enter a valid email address.</p>
        </div>

        <div class="field">
          <label for="loginPassword">Password</label>
          <div class="input-wrap">
            <input type="password" id="loginPassword" name="password" placeholder="Enter your password" autocomplete="current-password">
            <button type="button" class="toggle-pass" data-target="loginPassword">SHOW</button>
          </div>
          <p class="field-error" id="loginPasswordError">Password is required.</p>
        </div>

        <button type="submit" class="btn-submit">LOGIN</button>

        <p class="switch-text">Don't have an account? <a id="goRegister">Register</a></p>
      </form>

      <form class="auth-card" id="registerCard" method="post" action="login.php" novalidate>
        <h2>Create Account</h2>
        <input type="hidden" name="form_type" value="register">

        <?php foreach ($registerErrors as $err): ?>
          <p class="field-error show"><?= e($err) ?></p>
        <?php endforeach; ?>

        <div class="field-row">
          <div class="field">
            <label for="firstName">First Name</label>
            <div class="input-wrap">
              <input type="text" id="firstName" name="first_name" placeholder="First name" autocomplete="given-name" value="<?= e($regFirstName) ?>">
            </div>
          </div>
          <div class="field">
            <label for="lastName">Last Name</label>
            <div class="input-wrap">
              <input type="text" id="lastName" name="last_name" placeholder="Last name" autocomplete="family-name" value="<?= e($regLastName) ?>">
            </div>
          </div>
        </div>

        <div class="field">
          <label for="dob">Date of Birth</label>
          <div class="input-wrap">
            <input type="date" id="dob" name="date_of_birth" autocomplete="bday" value="<?= e($regDob) ?>">
          </div>
        </div>

        <div class="field">
          <label for="regEmail">Email</label>
          <div class="input-wrap">
            <input type="email" id="regEmail" name="email" placeholder="Enter your email" autocomplete="email" value="<?= e($regEmail) ?>">
          </div>
          <p class="field-error" id="regEmailError">Please enter a valid email address.</p>
        </div>

        <div class="field">
          <label for="regPassword">Password</label>
          <div class="input-wrap">
            <input type="password" id="regPassword" name="password" placeholder="Create a password" autocomplete="new-password">
            <button type="button" class="toggle-pass" data-target="regPassword">SHOW</button>
          </div>
          <p class="field-error" id="regPasswordError">Password must be at least 8 characters.</p>
        </div>

        <button type="submit" class="btn-submit">CREATE ACCOUNT</button>

        <p class="switch-text">Already have an account? <a id="goLogin">Login</a></p>
      </form>

    </div>
  </section>

</div>

<script>
(function () {
  var stage = document.getElementById('stage');
  var goRegister = document.getElementById('goRegister');
  var goLogin = document.getElementById('goLogin');

  goRegister.addEventListener('click', function () {
    stage.classList.add('register');
  });
  goLogin.addEventListener('click', function () {
    stage.classList.remove('register');
  });

  document.querySelectorAll('.toggle-pass').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = document.getElementById(btn.getAttribute('data-target'));
      var isPass = input.type === 'password';
      input.type = isPass ? 'text' : 'password';
      btn.textContent = isPass ? 'HIDE' : 'SHOW';
    });
  });

  function isEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }
  function setError(input, errorEl, show) {
    input.classList.toggle('invalid', show);
    if (errorEl) errorEl.classList.toggle('show', show);
  }

  document.getElementById('loginCard').addEventListener('submit', function (e) {
    var email = document.getElementById('loginEmail');
    var password = document.getElementById('loginPassword');
    var emailOk = isEmail(email.value.trim());
    var passOk = password.value.trim().length > 0;
    setError(email, document.getElementById('loginEmailError'), !emailOk);
    setError(password, document.getElementById('loginPasswordError'), !passOk);
    if (!emailOk || !passOk) {
      e.preventDefault();
    }
  });

  document.getElementById('registerCard').addEventListener('submit', function (e) {
    var email = document.getElementById('regEmail');
    var password = document.getElementById('regPassword');
    var emailOk = isEmail(email.value.trim());
    var passOk = password.value.length >= 8;
    setError(email, document.getElementById('regEmailError'), !emailOk);
    setError(password, document.getElementById('regPasswordError'), !passOk);
    if (!emailOk || !passOk) {
      e.preventDefault();
    }
  });

  document.querySelectorAll('.input-wrap input').forEach(function (input) {
    input.addEventListener('input', function () {
      input.classList.remove('invalid');
      var errEl = document.getElementById(input.id + 'Error');
      if (errEl) errEl.classList.remove('show');
    });
  });
})();
</script>
</body>
</html>
