<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login();

$q = clean_str($_GET['q'] ?? '');
$pageTitle = $q !== '' ? 'Search: ' . $q : 'Search';
$activeNav = '';

$results = ['movies' => [], 'games' => []];
if ($q !== '') {
    $results = search_all($q, 24);
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="content-header">
  <div>
    <h1>Search Results</h1>
    <?php if ($q !== ''): ?>
      <p class="content-sub">Showing results for "<?= e($q) ?>"</p>
    <?php else: ?>
      <p class="content-sub">Type something in the search bar above to find movies, games, or genres.</p>
    <?php endif; ?>
  </div>
</div>

<?php if ($q !== ''): ?>
  <?php if (empty($results['movies']) && empty($results['games'])): ?>
    <p class="empty-state">No results found for "<?= e($q) ?>".</p>
  <?php else: ?>
    <section class="content-section">
      <div class="section-header"><h2>&#127916; Movies</h2></div>
      <?php $items = $results['movies']; $emptyMessage = 'No matching movies.'; include __DIR__ . '/includes/item_grid.php'; ?>
    </section>
    <section class="content-section">
      <div class="section-header"><h2>&#127918; Games</h2></div>
      <?php $items = $results['games']; $emptyMessage = 'No matching games.'; include __DIR__ . '/includes/item_grid.php'; ?>
    </section>
  <?php endif; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
